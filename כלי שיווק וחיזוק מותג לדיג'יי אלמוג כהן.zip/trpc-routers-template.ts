import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

/**
 * Music Business Hub - tRPC Routers Template
 * 
 * This template provides the complete tRPC router structure for a music business platform.
 * Customize procedures, inputs, and business logic based on your needs.
 */

export const appRouter = router({
  // Dashboard - Real-time statistics and overview
  dashboard: router({
    stats: protectedProcedure.query(async ({ ctx }) => {
      const [leadStats, engagementStats, recentContent, competitorCount] = await Promise.all([
        db.getLeadStats(ctx.user.id),
        db.getEngagementStats(ctx.user.id),
        db.getContentPlans(ctx.user.id, 10),
        db.getCompetitors(ctx.user.id).then(c => c.length),
      ]);
      return {
        leads: leadStats,
        engagement: engagementStats,
        recentContent,
        competitorCount,
      };
    }),
  }),

  // Brand Management - Store and manage brand identity
  brand: router({
    getSettings: protectedProcedure.query(async ({ ctx }) => {
      return db.getBrandSettings(ctx.user.id);
    }),
    updateSettings: protectedProcedure
      .input(z.object({
        primaryColor: z.string().optional(),
        secondaryColor: z.string().optional(),
        accentColor: z.string().optional(),
        backgroundColor: z.string().optional(),
        toneOfVoice: z.string().optional(),
        brandValues: z.string().optional(),
        brandGuidelines: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.upsertBrandSettings(ctx.user.id, input);
        return { success: true };
      }),
  }),

  // Content Management - Plan and manage content
  content: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getContentPlans(ctx.user.id);
    }),
    create: protectedProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        pillar: z.enum(['authority', 'energy', 'mentor', 'person']),
        platform: z.enum(['instagram_reel', 'instagram_story', 'instagram_post', 'instagram_carousel']),
        content: z.string().optional(),
        hooks: z.string().optional(),
        captions: z.string().optional(),
        hashtags: z.string().optional(),
        scheduledDate: z.date().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createContentPlan(ctx.user.id, input);
      }),
  }),

  // Lead Management - Track and manage leads
  leads: router({
    list: protectedProcedure
      .input(z.object({
        type: z.enum(['wedding', 'dj_course', 'event', 'collaboration', 'other']).optional(),
      }))
      .query(async ({ ctx, input }) => {
        return db.getLeads(ctx.user.id, input.type);
      }),
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        type: z.enum(['wedding', 'dj_course', 'event', 'collaboration', 'other']),
        source: z.enum(['instagram', 'website', 'referral', 'direct', 'other']),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createLead(ctx.user.id, input);
      }),
  }),

  // Competitor Analysis - Track and analyze competitors
  competitors: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getCompetitors(ctx.user.id);
    }),
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        instagramHandle: z.string().optional(),
        website: z.string().optional(),
        specialization: z.string().optional(),
        mainMessages: z.string().optional(),
        targetAudience: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createCompetitor(ctx.user.id, input);
      }),
  }),

  // Analytics - Track content performance
  analytics: router({
    getContentPerformance: protectedProcedure
      .input(z.object({
        days: z.number().optional().default(30),
      }))
      .query(async ({ ctx, input }) => {
        return db.getContentAnalytics(ctx.user.id, input.days);
      }),
    recordAnalytic: protectedProcedure
      .input(z.object({
        contentPlanId: z.number().optional(),
        instagramPostId: z.string().optional(),
        likes: z.number().optional(),
        comments: z.number().optional(),
        shares: z.number().optional(),
        saves: z.number().optional(),
        reach: z.number().optional(),
        impressions: z.number().optional(),
        leadsGenerated: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.recordContentAnalytic(ctx.user.id, input);
      }),
  }),
});

export type AppRouter = typeof appRouter;
