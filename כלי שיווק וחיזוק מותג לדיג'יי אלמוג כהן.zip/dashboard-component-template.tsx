import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Users, TrendingUp, MessageSquare, Target } from "lucide-react";
import { trpc } from "@/lib/trpc";

/**
 * Music Business Hub - Dashboard Component Template
 * 
 * This template provides the main dashboard component with statistics and charts.
 * Customize metrics, colors, and layout based on your needs.
 */

export default function Dashboard() {
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();

  if (isLoading) {
    return <div className="p-8">טוען...</div>;
  }

  return (
    <div className="space-y-8 p-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">דשבורד</h1>
        <p className="text-gray-600 mt-2">סקירה כללית של הביצועים והלידים</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Leads */}
        <Card className="border-l-4 border-l-[#059cc0]">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Users className="w-4 h-4" />
              סה"כ לידים
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900">
              {stats?.leads?.totalLeads || 0}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              {stats?.leads?.weddingLeads || 0} חתונות, {stats?.leads?.courseLeads || 0} קורסים
            </p>
          </CardContent>
        </Card>

        {/* Engagement */}
        <Card className="border-l-4 border-l-[#03b28c]">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              אנגייג'מנט
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900">
              {stats?.engagement?.totalLikes || 0}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              {stats?.engagement?.totalComments || 0} תגובות
            </p>
          </CardContent>
        </Card>

        {/* Content Published */}
        <Card className="border-l-4 border-l-[#1f1f21]">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              תוכן פורסם
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900">
              {stats?.recentContent?.length || 0}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              בחודש האחרון
            </p>
          </CardContent>
        </Card>

        {/* Competitors */}
        <Card className="border-l-4 border-l-[#059cc0]">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Target className="w-4 h-4" />
              מתחרים
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900">
              {stats?.competitorCount || 0}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              בניתוח
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Engagement Trend */}
        <Card>
          <CardHeader>
            <CardTitle>טרנד אנגייג'מנט</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={stats?.recentContent || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="title" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="likes" stroke="#059cc0" />
                <Line type="monotone" dataKey="comments" stroke="#03b28c" />
                <Line type="monotone" dataKey="shares" stroke="#1f1f21" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Lead Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>התפלגות לידים</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={[
                { name: "חתונות", value: stats?.leads?.weddingLeads || 0 },
                { name: "קורסים", value: stats?.leads?.courseLeads || 0 },
              ]}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#059cc0" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>פעילות אחרונה</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {stats?.recentContent?.slice(0, 5).map((item: any) => (
              <div key={item.id} className="flex items-center justify-between border-b pb-4">
                <div>
                  <p className="font-medium">{item.title}</p>
                  <p className="text-sm text-gray-500">{item.platform}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{item.likes} likes</p>
                  <p className="text-xs text-gray-500">{item.comments} comments</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
