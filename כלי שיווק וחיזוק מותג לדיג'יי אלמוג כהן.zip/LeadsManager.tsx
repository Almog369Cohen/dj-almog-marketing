import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Loader2, Plus, Heart, BookOpen } from "lucide-react";

const LEAD_STATUSES = [
  { id: 'interested', label: 'מעוניין', color: '#03b28c' },
  { id: 'contacted', label: 'יצור קשר', color: '#059cc0' },
  { id: 'negotiating', label: 'משא ומתן', color: '#1f1f21' },
  { id: 'converted', label: 'הומר', color: '#059cc0' },
  { id: 'lost', label: 'אבוד', color: '#999' },
];

const LEAD_SOURCES = [
  { id: 'instagram', label: 'אינסטגרם' },
  { id: 'website', label: 'אתר' },
  { id: 'referral', label: 'הפניה' },
  { id: 'direct', label: 'ישיר' },
  { id: 'other', label: 'אחר' },
];

export default function LeadsManager() {
  const { user } = useAuth();
  const { data: weddingLeads, isLoading: loadingWedding, refetch: refetchWedding } = trpc.leads.list.useQuery({ type: 'wedding' });
  const { data: courseLeads, isLoading: loadingCourse, refetch: refetchCourse } = trpc.leads.list.useQuery({ type: 'dj_course' });
  
  const createMutation = trpc.leads.create.useMutation({
    onSuccess: () => {
      refetchWedding();
      refetchCourse();
      setIsOpen(false);
      resetForm();
    },
  });

  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('wedding');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    type: 'wedding',
    source: 'instagram',
    notes: '',
  });

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      type: 'wedding',
      source: 'instagram',
      notes: '',
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await createMutation.mutateAsync({
      name: formData.name,
      email: formData.email || undefined,
      phone: formData.phone || undefined,
      type: formData.type as 'wedding' | 'dj_course',
      source: formData.source as 'instagram' | 'website' | 'referral' | 'direct' | 'other',
      notes: formData.notes || undefined,
    });
  };

  if (!user) return null;

  const allLeads = [...(weddingLeads || []), ...(courseLeads || [])];
  const convertedCount = allLeads.filter(l => l.status === 'converted').length;
  const conversionRate = allLeads.length > 0 ? Math.round((convertedCount / allLeads.length) * 100) : 0;

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-foreground">ניהול לידים</h1>
            <p className="text-muted-foreground mt-2">עקוב אחרי לידים מחתונות וקורסי DJ</p>
          </div>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                לידים חדש
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>הוסיפו לידים חדש</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-sm font-medium">שם</label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="שם הלקוח"
                    required
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">דוא&quot;ל</label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="דוא&quot;ל"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">טלפון</label>
                  <Input
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="מספר טלפון"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">סוג</label>
                    <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="wedding">חתונה</SelectItem>
                        <SelectItem value="dj_course">קורס DJ</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium">מקור</label>
                    <Select value={formData.source} onValueChange={(value) => setFormData({ ...formData, source: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {LEAD_SOURCES.map((s) => (
                          <SelectItem key={s.id} value={s.id}>
                            {s.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium">הערות</label>
                  <Input
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="הערות נוספות"
                  />
                </div>

                <Button type="submit" disabled={createMutation.isPending} className="w-full">
                  {createMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      שומר...
                    </>
                  ) : (
                    'הוסיפו לידים'
                  )}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">סה"כ לידים</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{allLeads.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">הומרו</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{convertedCount}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">שיעור המרה</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{conversionRate}%</div>
            </CardContent>
          </Card>
        </div>

        {/* Leads Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="wedding" className="gap-2">
              <Heart className="w-4 h-4" />
              חתונות
            </TabsTrigger>
            <TabsTrigger value="courses" className="gap-2">
              <BookOpen className="w-4 h-4" />
              קורסים
            </TabsTrigger>
          </TabsList>

          <TabsContent value="wedding">
            <Card>
              <CardHeader>
                <CardTitle>לידי חתונה</CardTitle>
              </CardHeader>
              <CardContent>
                {loadingWedding ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : weddingLeads && weddingLeads.length > 0 ? (
                  <div className="space-y-3">
                    {weddingLeads.map((lead) => {
                      const status = LEAD_STATUSES.find(s => s.id === lead.status);
                      return (
                        <div key={lead.id} className="p-4 border rounded-lg">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <p className="font-medium">{lead.name}</p>
                              <p className="text-sm text-muted-foreground">{lead.email}</p>
                              {lead.phone && <p className="text-sm text-muted-foreground">{lead.phone}</p>}
                              <p className="text-xs text-muted-foreground mt-2">מקור: {LEAD_SOURCES.find(s => s.id === lead.source)?.label}</p>
                            </div>
                            <div className="text-right">
                              <span
                                className="text-xs px-2 py-1 rounded-full text-white"
                                style={{ backgroundColor: status?.color }}
                              >
                                {status?.label}
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-8">אין לידי חתונה עדיין</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="courses">
            <Card>
              <CardHeader>
                <CardTitle>לידי קורסים</CardTitle>
              </CardHeader>
              <CardContent>
                {loadingCourse ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : courseLeads && courseLeads.length > 0 ? (
                  <div className="space-y-3">
                    {courseLeads.map((lead) => {
                      const status = LEAD_STATUSES.find(s => s.id === lead.status);
                      return (
                        <div key={lead.id} className="p-4 border rounded-lg">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <p className="font-medium">{lead.name}</p>
                              <p className="text-sm text-muted-foreground">{lead.email}</p>
                              {lead.phone && <p className="text-sm text-muted-foreground">{lead.phone}</p>}
                              <p className="text-xs text-muted-foreground mt-2">מקור: {LEAD_SOURCES.find(s => s.id === lead.source)?.label}</p>
                            </div>
                            <div className="text-right">
                              <span
                                className="text-xs px-2 py-1 rounded-full text-white"
                                style={{ backgroundColor: status?.color }}
                              >
                                {status?.label}
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-8">אין לידי קורסים עדיין</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
