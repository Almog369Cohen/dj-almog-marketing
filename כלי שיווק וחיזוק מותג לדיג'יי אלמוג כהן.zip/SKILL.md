---
name: music-business-hub
description: "Build comprehensive music business management platforms with dashboard, content planning, lead management, document workflows, and e-signature support. Use for DJ/musician business management, content creator platforms, event management systems, course management, and client relationship management with contracts and proposals."
---

# Music Business Hub

## Overview

Music Business Hub is a complete business operating system for musicians, DJs, producers, and music educators. It provides an integrated platform for marketing, content management, lead tracking, document workflows, and e-signature capabilities—transforming a music business from scattered tools into a unified, professional system.

**Core Components:**
1. **Marketing Dashboard** - Real-time stats, content performance, engagement tracking
2. **Content Planning** - 4-pillar content system (Authority, Energy, Mentor, Person) with scheduling
3. **Lead Management** - Separate pipelines for weddings, courses, events, collaborations
4. **Competitor Analysis** - Track 20-30 competitors, identify positioning gaps
5. **Document Management** - Proposals, contracts, invoices, course materials
6. **E-Signature Workflows** - Client-facing forms with digital signatures
7. **Customer Journey** - From Instagram discovery to contract signing

## When to Use This Skill

Use Music Business Hub when building:
- DJ/musician business management platforms
- Music education/course platforms
- Event management systems
- Creative service marketplaces
- Music production studios
- Content creator management tools
- Any music/creative business needing unified operations

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend (React 19)                      │
├─────────────────────────────────────────────────────────────┤
│  Dashboard │ Content Planner │ Leads │ Competitors │ Docs  │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                  Backend (Express + tRPC)                   │
├─────────────────────────────────────────────────────────────┤
│  Dashboard │ Brand │ Content │ Leads │ Competitors │ Docs  │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                 Database (MySQL/TiDB)                       │
├─────────────────────────────────────────────────────────────┤
│ brand_settings │ content_plans │ leads │ competitors │      │
│ content_analytics │ documents │ signatures │ invoices       │
└─────────────────────────────────────────────────────────────┘
```

## Core Capabilities

### 1. Marketing Dashboard
Real-time overview of business performance with key metrics:
- **Lead Statistics**: Total leads, wedding leads, course leads, converted leads
- **Engagement Metrics**: Likes, comments, shares, reach, impressions
- **Content Performance**: Published content, trending topics, best performers
- **Competitor Tracking**: Number of competitors, positioning gaps, market trends

**Implementation**: Use `dashboard-component-template.tsx` and `trpc.dashboard.stats` procedure.

### 2. Content Planning System
Organize content around 4 business pillars with monthly planning:

**Four Pillars:**
- **Authority** - Expertise, tips, tutorials, industry insights
- **Energy** - Behind-the-scenes, hype, excitement, entertainment
- **Mentor** - Teaching moments, course previews, value delivery
- **Person** - Personal stories, day-in-life, authentic connection

**Platforms Supported:**
- Instagram Reels
- Instagram Stories
- Instagram Posts
- Instagram Carousel

**Features:**
- Monthly calendar view
- Content scheduling
- Status tracking (draft → scheduled → published)
- Hook and caption templates
- Hashtag suggestions
- Media upload integration

### 3. Lead Management
Dual-pipeline system for different customer types:

**Lead Types:**
- Wedding DJ services
- DJ course enrollments
- Event bookings
- Collaborations
- Other inquiries

**Lead Status Workflow:**
```
Interested → Contacted → Negotiating → Converted
                                    ↓
                                   Lost
```

**Lead Sources:**
- Instagram
- Website
- Referral
- Direct contact
- Other

**Features:**
- Lead capture forms
- Status tracking with history
- Lead conversion funnel
- Lead source analytics
- Automatic follow-up reminders

### 4. Competitor Analysis
Track and analyze competing DJs/musicians to identify market opportunities:

**Tracking Elements:**
- Competitor name and contact info
- Instagram handle and follower count
- Website and specialization
- Main messages and positioning
- Target audience
- Content style and frequency
- Strengths and weaknesses
- Positioning gaps (opportunities for you)

**Analysis Features:**
- Competitor dashboard
- Message frequency analysis
- Content style comparison
- Positioning gap identification
- Market trend detection

### 5. Document Management & E-Signatures
Complete workflow for contracts, proposals, and agreements:

**Document Types:**

#### Proposals & Quotes
- Event proposal template
- Pricing quote template
- Service package description
- Terms and conditions
- Client information capture

#### Contracts
- Wedding DJ contract
- Event DJ contract
- Course enrollment agreement
- Collaboration agreement
- Cancellation and refund policy

#### Invoices & Receipts
- Professional invoice template
- Payment tracking
- Automatic reminders
- Receipt generation

#### Course Materials
- Course syllabus
- Student enrollment form
- Certificate of completion
- Course materials (PDFs, videos)

#### Administrative
- Booking confirmation
- Payment receipt
- Thank you letter
- Follow-up surveys

**E-Signature Workflow:**
```
1. Business creates document (proposal/contract)
2. Document sent to client via email link
3. Client reviews and signs (e-signature)
4. Signature captured and stored
5. Document marked as signed
6. Automatic follow-up triggered
```

### 6. Customer Journey Mapping
Complete flow from discovery to contract signing:

```
Instagram Post
     ↓
Profile Visit
     ↓
Website/Landing Page
     ↓
Lead Capture Form
     ↓
Proposal/Quote Sent
     ↓
E-Signature Request
     ↓
Contract Signed
     ↓
Invoice & Payment
     ↓
Confirmation & Onboarding
```

### 7. Brand Management
Centralized brand identity system:

**Brand Elements:**
- Primary color (#059cc0 - Teal)
- Secondary color (#03b28c - Green)
- Accent color (#1f1f21 - Dark)
- Background color (#ffffff - White)
- Tone of voice guidelines
- Brand values
- Brand guidelines document

**Usage:**
- Consistent styling across all documents
- Automatic color application in generated PDFs
- Brand compliance checking

## Implementation Workflow

### Step 1: Project Setup
```bash
# Initialize new Manus webdev project with db+server+user features
webdev_init_project --name my-music-business --features db,server,user
```

### Step 2: Database Schema
1. Copy `drizzle-schema-template.ts` to `drizzle/schema.ts`
2. Run `python scripts/generate_schema.py`
3. Execute generated migrations with `webdev_execute_sql`

**Key Tables:**
- `brand_settings` - Business branding
- `content_plans` - Content calendar
- `leads` - Lead tracking
- `competitors` - Competitor analysis
- `content_analytics` - Performance metrics
- `documents` - Stored documents
- `signatures` - E-signature records
- `invoices` - Invoice tracking

### Step 3: Backend Implementation
1. Copy `db-helpers-template.ts` to `server/db.ts`
2. Copy `trpc-routers-template.ts` to `server/routers.ts`
3. Add document management routers (see references/document-workflows.md)
4. Add e-signature routers (see references/esignature-integration.md)

### Step 4: Frontend Components
Create pages in `client/src/pages/`:
- `Dashboard.tsx` - Marketing overview
- `ContentPlanner.tsx` - Content calendar
- `LeadsManager.tsx` - Lead tracking
- `CompetitorAnalysis.tsx` - Competitor insights
- `DocumentManager.tsx` - Document storage and generation
- `SignatureWorkflow.tsx` - E-signature client interface
- `BrandSettings.tsx` - Brand configuration

Use `dashboard-component-template.tsx` as starting point.

### Step 5: Document Generation
1. Set up PDF generation (use `reportlab` or `weasyprint`)
2. Create document templates for each type
3. Implement merge fields (client name, date, price, etc.)
4. Set up e-signature integration

### Step 6: E-Signature Integration
1. Choose provider (DocuSign, HelloSign, or custom implementation)
2. Implement signature capture workflow
3. Set up webhook for signature completion
4. Store signed documents in database

### Step 7: Testing & Deployment
1. Write vitest tests for all routers
2. Test document generation
3. Test e-signature workflow end-to-end
4. Deploy to Manus platform

## Customization Guide

### Add New Document Type
1. Create template in `templates/documents/`
2. Add document type enum to schema
3. Create tRPC mutation for generation
4. Build UI form for document data
5. Test PDF generation

### Add New Lead Type
1. Update `leads.type` enum in schema
2. Generate and apply migration
3. Update tRPC input schema
4. Update lead management UI
5. Add lead-specific workflows

### Support Multiple Languages
1. Add i18n configuration
2. Create translation files for Hebrew, Arabic, English
3. Use `useTranslation()` hook in components
4. Test RTL layout

### Integrate Instagram API
1. Get Instagram Graph API credentials
2. Create server-side API client
3. Add procedures to fetch real analytics
4. Update dashboard with live data

### Add Payment Processing
1. Integrate Stripe or PayPal
2. Create payment procedure
3. Update invoice workflow
4. Add payment status tracking

## Common Workflows

### Workflow 1: Quote to Contract to Payment
```
1. Lead inquires about wedding DJ
2. Business creates proposal with pricing
3. Proposal sent to client via e-signature link
4. Client reviews and signs
5. Signed contract stored in database
6. Invoice automatically generated
7. Payment link sent to client
8. Payment received and confirmed
9. Booking confirmation sent
```

### Workflow 2: Course Enrollment
```
1. Prospect visits course landing page
2. Fills enrollment form
3. Course agreement sent for signature
4. Client signs agreement
5. Invoice generated
6. Payment processed
7. Course access granted
8. Welcome email with materials
9. Course progress tracked
```

### Workflow 3: Content to Lead
```
1. Create content in Content Planner
2. Schedule for publication
3. Content published to Instagram
4. Track engagement metrics
5. Identify interested leads from comments
6. Add to lead database
7. Send DM or email follow-up
8. Move through sales pipeline
```

## Resources

### Templates
- `drizzle-schema-template.ts` - Complete database schema
- `trpc-routers-template.ts` - tRPC router structure
- `db-helpers-template.ts` - Database query helpers
- `dashboard-component-template.tsx` - Dashboard component
- `documents/proposal-template.html` - Proposal template
- `documents/contract-template.html` - Contract template
- `documents/invoice-template.html` - Invoice template

### References
- `implementation-guide.md` - Step-by-step implementation
- `document-workflows.md` - Document generation and management
- `esignature-integration.md` - E-signature implementation
- `customer-journey.md` - Customer journey mapping
- `database-schema.md` - Detailed schema documentation

### Scripts
- `generate_schema.py` - Schema generation helper
- `generate_documents.py` - Document generation utilities
- `setup_esignature.py` - E-signature setup helper

## Best Practices

### Content Planning
- Plan monthly content in advance
- Balance all 4 pillars evenly
- Schedule content during peak engagement times
- Monitor performance and adjust strategy
- Repurpose top-performing content

### Lead Management
- Follow up within 24 hours
- Personalize communication
- Track all interactions
- Move leads through pipeline systematically
- Analyze conversion rates by source

### Document Management
- Use consistent branding
- Keep templates up-to-date
- Store all signed documents
- Maintain audit trail
- Back up important documents

### Competitor Analysis
- Update competitor data monthly
- Look for positioning gaps
- Monitor content changes
- Track new services/offerings
- Identify market trends

## Troubleshooting

### Document Generation Issues
**Problem**: PDF generation fails
**Solution**: Check file paths, ensure fonts are available, verify HTML/CSS syntax

### E-Signature Workflow Issues
**Problem**: Client doesn't receive signature link
**Solution**: Check email configuration, verify client email address, check spam folder

### Lead Status Not Updating
**Problem**: Lead status stuck in one status
**Solution**: Check database permissions, verify tRPC mutation, check UI form submission

### Content Not Publishing
**Problem**: Scheduled content doesn't publish
**Solution**: Check timezone settings, verify Instagram API credentials, check scheduled date/time

## Next Steps

1. **Implement core dashboard** - Get real-time stats working
2. **Build content planner** - Set up 4-pillar content system
3. **Add lead management** - Create dual pipelines
4. **Integrate documents** - Set up proposal/contract generation
5. **Add e-signatures** - Implement client signing workflow
6. **Connect Instagram API** - Get real analytics
7. **Add payment processing** - Integrate Stripe
8. **Build reporting** - Create business intelligence dashboards

## Support & Iteration

After implementing, test with real workflows:
1. Create a test proposal and send to yourself
2. Sign it using the e-signature workflow
3. Generate an invoice
4. Track a lead through the entire pipeline
5. Analyze content performance

Iterate based on real usage patterns and user feedback.
