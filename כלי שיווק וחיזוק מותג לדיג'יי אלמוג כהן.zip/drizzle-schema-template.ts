import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Music Business Hub - Drizzle Schema Template
 * 
 * This template provides the complete database schema for a music business management platform.
 * Customize table names, fields, and enums based on your specific needs.
 */

// Core user table (already exists in template)
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

// Brand Settings - Store business branding and identity
export const brandSettings = mysqlTable("brand_settings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  primaryColor: varchar("primaryColor", { length: 7 }).notNull().default("#000000"),
  secondaryColor: varchar("secondaryColor", { length: 7 }).notNull().default("#ffffff"),
  accentColor: varchar("accentColor", { length: 7 }).notNull().default("#666666"),
  backgroundColor: varchar("backgroundColor", { length: 7 }).notNull().default("#ffffff"),
  toneOfVoice: text("toneOfVoice"),
  brandValues: text("brandValues"),
  brandGuidelines: text("brandGuidelines"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Content Plans - Plan and track content across platforms
export const contentPlans = mysqlTable("content_plans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  pillar: mysqlEnum("pillar", ["authority", "energy", "mentor", "person"]).notNull(),
  platform: mysqlEnum("platform", ["instagram_reel", "instagram_story", "instagram_post", "instagram_carousel"]).notNull(),
  status: mysqlEnum("status", ["draft", "scheduled", "published", "archived"]).notNull().default("draft"),
  scheduledDate: timestamp("scheduledDate"),
  publishedDate: timestamp("publishedDate"),
  content: text("content"),
  hooks: text("hooks"),
  captions: text("captions"),
  hashtags: text("hashtags"),
  mediaUrls: text("mediaUrls"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Leads - Track potential customers/clients
export const leads = mysqlTable("leads", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  type: mysqlEnum("type", ["wedding", "dj_course", "event", "collaboration", "other"]).notNull(),
  status: mysqlEnum("status", ["interested", "contacted", "negotiating", "converted", "lost"]).notNull().default("interested"),
  source: mysqlEnum("source", ["instagram", "website", "referral", "direct", "other"]).notNull(),
  eventDate: timestamp("eventDate"),
  budget: int("budget"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Competitors - Track and analyze competitors
export const competitors = mysqlTable("competitors", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  instagramHandle: varchar("instagramHandle", { length: 255 }),
  website: varchar("website", { length: 255 }),
  specialization: varchar("specialization", { length: 255 }),
  mainMessages: text("mainMessages"),
  targetAudience: text("targetAudience"),
  strengths: text("strengths"),
  weaknesses: text("weaknesses"),
  positioningGaps: text("positioningGaps"),
  contentStyle: text("contentStyle"),
  lastAnalyzedAt: timestamp("lastAnalyzedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Content Templates - Reusable content templates
export const contentTemplates = mysqlTable("content_templates", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["reel", "story", "value_post", "carousel"]).notNull(),
  pillar: mysqlEnum("pillar", ["authority", "energy", "mentor", "person"]).notNull(),
  hooks: text("hooks"),
  headlines: text("headlines"),
  structure: text("structure"),
  callToAction: text("callToAction"),
  bestPractices: text("bestPractices"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Content Analytics - Track performance metrics
export const contentAnalytics = mysqlTable("content_analytics", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  contentPlanId: int("contentPlanId"),
  instagramPostId: varchar("instagramPostId", { length: 255 }),
  likes: int("likes").default(0),
  comments: int("comments").default(0),
  shares: int("shares").default(0),
  saves: int("saves").default(0),
  reach: int("reach").default(0),
  impressions: int("impressions").default(0),
  engagement: int("engagement").default(0),
  leadsGenerated: int("leadsGenerated").default(0),
  conversionRate: int("conversionRate").default(0),
  recordedAt: timestamp("recordedAt").defaultNow().notNull(),
});

// Export types for TypeScript
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type BrandSettings = typeof brandSettings.$inferSelect;
export type InsertBrandSettings = typeof brandSettings.$inferInsert;
export type ContentPlan = typeof contentPlans.$inferSelect;
export type InsertContentPlan = typeof contentPlans.$inferInsert;
export type Lead = typeof leads.$inferSelect;
export type InsertLead = typeof leads.$inferInsert;
export type Competitor = typeof competitors.$inferSelect;
export type InsertCompetitor = typeof competitors.$inferInsert;
export type ContentTemplate = typeof contentTemplates.$inferSelect;
export type InsertContentTemplate = typeof contentTemplates.$inferInsert;
export type ContentAnalytic = typeof contentAnalytics.$inferSelect;
export type InsertContentAnalytic = typeof contentAnalytics.$inferInsert;
