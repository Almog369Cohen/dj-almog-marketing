# 🎵 DJ Almog Cohen Marketing Hub - Claude Code Handoff

## 📌 Project Overview

**Project Name:** DJ Almog Cohen Marketing Hub  
**Repository:** https://github.com/Almog369Cohen/dj-almog-marketing  
**Live URL:** https://almoghub-rb3jrguk.manus.space  
**Language:** Hebrew (עברית)  
**Tech Stack:** React 19 + Tailwind 4 + Express 4 + tRPC 11 + MySQL/TiDB

---

## 🎯 Project Purpose

A complete **Business Operating System** for DJ Almog Cohen to manage:
- 📊 Marketing dashboard with real-time statistics
- 📝 Content planning with 4-pillar system (Authority, Energy, Mentor, Person)
- 👥 Lead management (weddings & DJ courses)
- 🔍 Competitor analysis (20-30 Israeli DJs)
- 📋 Document & contract management
- 💰 Invoice & payment tracking
- ✍️ E-signature workflows

---

## 🏗️ Architecture

### Database Schema (MySQL/TiDB)

**Core Tables:**
- `users` - Authentication & user management
- `brandSettings` - Brand colors, tone of voice, values
- `contentPlans` - Monthly content planning
- `leads` - Lead management (weddings, courses)
- `competitors` - Competitor tracking
- `contentTemplates` - Reusable content templates
- `contentAnalytics` - Performance metrics
- `documents` - Proposals, contracts, receipts
- `signatures` - E-signature records
- `invoices` - Invoice management
- `documentTemplates` - Document templates

### Backend Structure

**tRPC Routers** (`server/routers.ts`):
- `auth` - Login/logout
- `dashboard` - Statistics & metrics
- `contentPlans` - CRUD operations
- `leads` - Lead management
- `competitors` - Competitor tracking
- `documents` - Document management
- `signatures` - E-signature handling
- `invoices` - Invoice management

**Database Helpers** (`server/db.ts`):
- Query functions for all tables
- Aggregation for statistics
- Lead conversion tracking

### Frontend Structure

**Pages** (`client/src/pages/`):
1. `Home.tsx` - Landing page with navigation
2. `Dashboard.tsx` - Main dashboard with statistics
3. `ContentPlanner.tsx` - Monthly content planning
4. `LeadsManager.tsx` - Lead tracking & management
5. `CompetitorAnalysis.tsx` - Competitor insights
6. `DocumentManager.tsx` - Document & contract management
7. `InvoiceManager.tsx` - Invoice lifecycle
8. `SignatureWidget.tsx` - E-signature capture

**Navigation** (`DashboardLayout.tsx`):
- Sidebar with 6 main sections
- User profile & logout
- Responsive design

---

## 🎨 Brand Colors

```
Primary Blue:    #059cc0 (R5 G156 B192)
Secondary Green: #03b28c (R3 G178 B140)
Dark Gray:       #1f1f21 (R31 G31 B33)
White:           #ffffff (R255 G255 B255)
```

All components use these colors consistently.

---

## 🚀 Key Features

### 1. Dashboard
- Real-time statistics (leads, content, competitors)
- Performance charts (likes, comments, shares)
- Quick action buttons
- Status overview cards

### 2. Content Planning
- Monthly calendar view
- 4-pillar content system
- Content status tracking (draft → scheduled → published)
- Bulk scheduling

### 3. Lead Management
- Separate tracking for weddings & courses
- Lead status workflow (interested → contacted → converted → lost)
- Lead source tracking
- Conversion metrics

### 4. Competitor Analysis
- Track 20-30 competitors
- Message analysis
- Positioning gaps identification
- Competitive insights

### 5. Document Management
- Create proposals, contracts, receipts
- Template system
- Status tracking (draft → sent → signed → archived)
- Email integration ready

### 6. E-Signature
- Digital signature capture
- IP & User Agent verification
- Timestamp recording
- Audit trail

### 7. Invoice Management
- Full invoice lifecycle
- Payment status tracking
- Revenue analytics
- Pending payment alerts

---

## 📂 Project Structure

```
almog-cohen-marketing-hub/
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.tsx
│   │   │   ├── Dashboard.tsx
│   │   │   ├── ContentPlanner.tsx
│   │   │   ├── LeadsManager.tsx
│   │   │   ├── CompetitorAnalysis.tsx
│   │   │   ├── DocumentManager.tsx
│   │   │   ├── InvoiceManager.tsx
│   │   │   └── SignatureWidget.tsx
│   │   ├── components/
│   │   │   ├── DashboardLayout.tsx
│   │   │   ├── DashboardLayoutSkeleton.tsx
│   │   │   └── ui/ (shadcn/ui components)
│   │   ├── App.tsx
│   │   ├── lib/trpc.ts
│   │   └── index.css (global styles)
│   └── public/
├── server/
│   ├── routers.ts (tRPC procedures)
│   ├── db.ts (database helpers)
│   ├── features.test.ts (vitest tests)
│   └── _core/ (framework internals)
├── drizzle/
│   ├── schema.ts (database schema)
│   └── migrations/ (SQL migrations)
├── shared/
│   └── const.ts (shared constants)
└── package.json
```

---

## 🔧 Development Workflow

### Running Locally
```bash
cd almog-cohen-marketing-hub
pnpm install
pnpm dev
# Server: http://localhost:3000
```

### Database Migrations
```bash
# 1. Update schema in drizzle/schema.ts
# 2. Generate migration
pnpm drizzle-kit generate

# 3. Apply migration (use webdev_execute_sql in Manus)
```

### Testing
```bash
pnpm test  # Run vitest tests
pnpm check # TypeScript check
```

---

## 🔐 Environment Variables

**Pre-configured by Manus:**
- `DATABASE_URL` - MySQL connection string
- `JWT_SECRET` - Session signing secret
- `VITE_APP_ID` - OAuth application ID
- `OAUTH_SERVER_URL` - OAuth backend
- `VITE_OAUTH_PORTAL_URL` - Login portal
- `OWNER_OPEN_ID` - Owner's OAuth ID
- `OWNER_NAME` - Owner's name
- `BUILT_IN_FORGE_API_URL` - Manus APIs
- `BUILT_IN_FORGE_API_KEY` - API key
- `VITE_FRONTEND_FORGE_API_KEY` - Frontend API key

---

## 📊 Current Status

✅ **Completed:**
- Database schema with 10 tables
- tRPC routers for all features
- 8 frontend pages
- Dashboard with statistics
- Content planning system
- Lead management
- Competitor tracking
- Document management
- Invoice management
- E-signature support
- Hebrew language support
- Brand color implementation

⏳ **Ready for Enhancement:**
- Email integration (send documents, invoices)
- Payment gateway (Stripe)
- Content idea generator (AI-powered)
- Instagram API integration
- Automated reporting
- Mobile app version

---

## 🎯 Next Steps for Claude Code

### Priority 1: Email Integration
**Goal:** Send documents & invoices automatically  
**Implementation:**
- Add Resend or SendGrid integration
- Create email templates
- Add send buttons to DocumentManager & InvoiceManager
- Track email opens & clicks

### Priority 2: Payment Gateway
**Goal:** Accept payments directly  
**Implementation:**
- Integrate Stripe
- Add payment form to invoices
- Create payment confirmation flow
- Update invoice status automatically

### Priority 3: AI Content Generator
**Goal:** Suggest content ideas based on trends  
**Implementation:**
- Analyze competitor content
- Generate content ideas
- Suggest optimal posting times
- Recommend hashtags

### Priority 4: Instagram Integration
**Goal:** Pull real engagement metrics  
**Implementation:**
- Connect Instagram API
- Fetch post metrics
- Update analytics dashboard
- Track follower growth

---

## 🧪 Testing

**Vitest tests included:**
- `server/features.test.ts` - 17 passing tests
- Database query helpers
- tRPC procedure validation
- Lead conversion tracking

**Run tests:**
```bash
pnpm test
```

---

## 📝 Code Standards

- **Language:** TypeScript (strict mode)
- **Styling:** Tailwind CSS 4 with custom theme
- **Components:** shadcn/ui
- **State Management:** React Query (via tRPC)
- **Testing:** Vitest
- **Formatting:** Prettier
- **RTL:** Full Hebrew support

---

## 🤝 Collaboration Notes

**Manus handles:**
- Infrastructure & deployment
- Database management
- OAuth & authentication
- Environment variables
- Hosting & domain management

**Claude Code can handle:**
- Feature development
- Bug fixes
- UI/UX improvements
- Performance optimization
- Testing

**Communication:**
- Use GitHub issues for tracking
- Reference this document for architecture
- Check `todo.md` for current tasks

---

## 📞 Quick Reference

**GitHub:** https://github.com/Almog369Cohen/dj-almog-marketing  
**Live Site:** https://almoghub-rb3jrguk.manus.space  
**Database:** MySQL/TiDB (managed by Manus)  
**Deployment:** Manus platform  

---

## 🎓 Learning Resources

- **tRPC:** https://trpc.io
- **React 19:** https://react.dev
- **Tailwind 4:** https://tailwindcss.com
- **Drizzle ORM:** https://orm.drizzle.team
- **shadcn/ui:** https://ui.shadcn.com

---

**Last Updated:** March 26, 2026  
**Status:** Ready for development  
**Maintainer:** Manus AI + Claude Code
