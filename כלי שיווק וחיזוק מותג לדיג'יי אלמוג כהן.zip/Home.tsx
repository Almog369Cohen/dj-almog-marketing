import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, Users, TrendingUp, Zap } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (isAuthenticated && user) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, user, navigate]);

  if (isAuthenticated && user) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg" style={{ backgroundColor: '#059cc0' }} />
            <span className="font-bold text-lg">DJ Almog Hub</span>
          </div>
          <Button onClick={() => window.location.href = getLoginUrl()}>התחברו</Button>
        </div>
      </header>

      {/* Hero */}
      <section className="flex-1 max-w-7xl mx-auto px-4 py-20 flex flex-col justify-center w-full">
        <div className="space-y-6 mb-12">
          <h1 className="text-5xl font-bold text-gray-900 leading-tight">
            פלטפורמה ניהול עסק DJ מקיפה
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl">
            תכננו תוכן, עקוב אחרי לידים, נתחו מתחרים וגדלו את המותג שלכם באינסטגרם
          </p>
          <div className="flex gap-4">
            <Button
              size="lg"
              onClick={() => window.location.href = getLoginUrl()}
              style={{ backgroundColor: '#059cc0' }}
              className="text-white"
            >
              התחילו עכשיו
            </Button>
            <Button size="lg" variant="outline">
              למידע נוסף
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">תכונות עיקריות</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader>
                <BarChart3 className="w-8 h-8" style={{ color: '#059cc0' }} />
                <CardTitle>דשבורד בזמן אמת</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">עקוב אחרי סטטיסטיקות, לידים ותוכן בזמן אמת</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Zap className="w-8 h-8" style={{ color: '#03b28c' }} />
                <CardTitle>תכנון תוכן</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">תכננו תוכן חודשי עם 4 עמודים: Authority, Energy, Mentor, Person</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Users className="w-8 h-8" style={{ color: '#1f1f21' }} />
                <CardTitle>ניהול לידים</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">עקוב אחרי לידים לחתונות וקורסי DJ בנפרד</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <TrendingUp className="w-8 h-8" style={{ color: '#059cc0' }} />
                <CardTitle>ניתוח מתחרים</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">עקוב אחרי 20-30 דיג'יים מתחרים וזהו חללים פתוחים</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 text-center space-y-6">
          <h2 className="text-3xl font-bold">מוכנים להתחיל?</h2>
          <p className="text-lg text-gray-600">הצטרפו לדיג'יים שכבר משתמשים בפלטפורמה כדי לגדול</p>
          <Button
            size="lg"
            onClick={() => window.location.href = getLoginUrl()}
            style={{ backgroundColor: '#059cc0' }}
            className="text-white"
          >
            התחברו עכשיו
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-gray-600">
          <p>© 2026 DJ Almog Marketing Hub. כל הזכויות שמורות.</p>
        </div>
      </footer>
    </div>
  );
}
