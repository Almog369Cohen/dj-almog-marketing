import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Loader2, Plus, TrendingUp } from "lucide-react";

export default function CompetitorAnalysis() {
  const { user } = useAuth();
  const { data: competitors, isLoading, refetch } = trpc.competitors.list.useQuery();
  const createMutation = trpc.competitors.create.useMutation({
    onSuccess: () => {
      refetch();
      setIsOpen(false);
      resetForm();
    },
  });

  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    instagramHandle: '',
    website: '',
    specialization: '',
    mainMessages: '',
    targetAudience: '',
  });

  const resetForm = () => {
    setFormData({
      name: '',
      instagramHandle: '',
      website: '',
      specialization: '',
      mainMessages: '',
      targetAudience: '',
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await createMutation.mutateAsync(formData);
  };

  if (!user) return null;

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-foreground">ניתוח מתחרים</h1>
            <p className="text-muted-foreground mt-2">עקוב אחרי 20-30 דיג'יים מתחרים בישראל</p>
          </div>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                מתחרה חדש
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>הוסיפו מתחרה חדש</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-sm font-medium">שם</label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="שם הדיג'יי"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Instagram Handle</label>
                    <Input
                      value={formData.instagramHandle}
                      onChange={(e) => setFormData({ ...formData, instagramHandle: e.target.value })}
                      placeholder="@username"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium">אתר</label>
                    <Input
                      value={formData.website}
                      onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                      placeholder="https://..."
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium">התמחות</label>
                  <Input
                    value={formData.specialization}
                    onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                    placeholder="לדוגמה: חתונות, אירועים, מוזיקה אלקטרונית"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">מסרים ראשיים</label>
                  <Textarea
                    value={formData.mainMessages}
                    onChange={(e) => setFormData({ ...formData, mainMessages: e.target.value })}
                    placeholder="מה הם משדרים בתוכן שלהם?"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">קהל יעד</label>
                  <Textarea
                    value={formData.targetAudience}
                    onChange={(e) => setFormData({ ...formData, targetAudience: e.target.value })}
                    placeholder="מי הקהל שלהם?"
                  />
                </div>

                <Button type="submit" disabled={createMutation.isPending} className="w-full">
                  {createMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      שומר...
                    </>
                  ) : (
                    'הוסיפו מתחרה'
                  )}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Competitors Grid */}
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin" />
          </div>
        ) : competitors && competitors.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {competitors.map((competitor) => (
              <Card key={competitor.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{competitor.name}</span>
                    <TrendingUp className="w-4 h-4 text-muted-foreground" />
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {competitor.specialization && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground">התמחות</p>
                      <p className="text-sm">{competitor.specialization}</p>
                    </div>
                  )}

                  {competitor.instagramHandle && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground">Instagram</p>
                      <a
                        href={`https://instagram.com/${competitor.instagramHandle}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-blue-600 hover:underline"
                      >
                        {competitor.instagramHandle}
                      </a>
                    </div>
                  )}

                  {competitor.mainMessages && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground">מסרים ראשיים</p>
                      <p className="text-sm line-clamp-2">{competitor.mainMessages}</p>
                    </div>
                  )}

                  {competitor.targetAudience && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground">קהל יעד</p>
                      <p className="text-sm line-clamp-2">{competitor.targetAudience}</p>
                    </div>
                  )}

                  {competitor.lastAnalyzedAt && (
                    <p className="text-xs text-muted-foreground pt-2 border-t">
                      נותח לאחרונה: {new Date(competitor.lastAnalyzedAt).toLocaleDateString('he-IL')}
                    </p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">אין מתחרים עדיין. התחילו בלחיצה על "מתחרה חדש"</p>
            </CardContent>
          </Card>
        )}

        {/* Insights Section */}
        {competitors && competitors.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>תובנות מתחרים</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-sm font-medium text-muted-foreground">סה"כ מתחרים</p>
                  <p className="text-2xl font-bold mt-2">{competitors.length}</p>
                </div>

                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-sm font-medium text-muted-foreground">עם Instagram</p>
                  <p className="text-2xl font-bold mt-2">
                    {competitors.filter(c => c.instagramHandle).length}
                  </p>
                </div>

                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-sm font-medium text-muted-foreground">עם אתר</p>
                  <p className="text-2xl font-bold mt-2">
                    {competitors.filter(c => c.website).length}
                  </p>
                </div>
              </div>

              <div className="p-4 border rounded-lg">
                <p className="text-sm font-medium mb-3">הצעות לשיפור</p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• בדקו את המסרים הנפוצים בקרב המתחרים</li>
                  <li>• זהו חללים פתוחים שלא מכוסים</li>
                  <li>• בנו אסטרטגיה שמבדלת אתכם</li>
                  <li>• עקוב אחרי שינויים בתוכן שלהם</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
