CREATE TABLE `brand_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`primaryColor` varchar(7) NOT NULL DEFAULT '#059cc0',
	`secondaryColor` varchar(7) NOT NULL DEFAULT '#03b28c',
	`accentColor` varchar(7) NOT NULL DEFAULT '#1f1f21',
	`backgroundColor` varchar(7) NOT NULL DEFAULT '#ffffff',
	`toneOfVoice` text,
	`brandValues` text,
	`brandGuidelines` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `brand_settings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `competitors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`instagramHandle` varchar(255),
	`website` varchar(255),
	`specialization` varchar(255),
	`mainMessages` text,
	`targetAudience` text,
	`strengths` text,
	`weaknesses` text,
	`positioningGaps` text,
	`contentStyle` text,
	`lastAnalyzedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `competitors_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `content_analytics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`contentPlanId` int,
	`instagramPostId` varchar(255),
	`likes` int DEFAULT 0,
	`comments` int DEFAULT 0,
	`shares` int DEFAULT 0,
	`saves` int DEFAULT 0,
	`reach` int DEFAULT 0,
	`impressions` int DEFAULT 0,
	`engagement` int DEFAULT 0,
	`leadsGenerated` int DEFAULT 0,
	`conversionRate` int DEFAULT 0,
	`recordedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `content_analytics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `content_plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`pillar` enum('authority','energy','mentor','person') NOT NULL,
	`platform` enum('instagram_reel','instagram_story','instagram_post','instagram_carousel') NOT NULL,
	`status` enum('draft','scheduled','published','archived') NOT NULL DEFAULT 'draft',
	`scheduledDate` timestamp,
	`publishedDate` timestamp,
	`content` text,
	`hooks` text,
	`captions` text,
	`hashtags` text,
	`mediaUrls` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `content_plans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `content_templates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` enum('reel','story','value_post','carousel') NOT NULL,
	`pillar` enum('authority','energy','mentor','person') NOT NULL,
	`hooks` text,
	`headlines` text,
	`structure` text,
	`callToAction` text,
	`bestPractices` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `content_templates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `leads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320),
	`phone` varchar(20),
	`type` enum('wedding','dj_course') NOT NULL,
	`status` enum('interested','contacted','negotiating','converted','lost') NOT NULL DEFAULT 'interested',
	`source` enum('instagram','website','referral','direct','other') NOT NULL,
	`eventDate` timestamp,
	`budget` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `leads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `brand_settings` ADD CONSTRAINT `brand_settings_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `competitors` ADD CONSTRAINT `competitors_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `content_analytics` ADD CONSTRAINT `content_analytics_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `content_analytics` ADD CONSTRAINT `content_analytics_contentPlanId_content_plans_id_fk` FOREIGN KEY (`contentPlanId`) REFERENCES `content_plans`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `content_plans` ADD CONSTRAINT `content_plans_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `content_templates` ADD CONSTRAINT `content_templates_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `leads` ADD CONSTRAINT `leads_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;