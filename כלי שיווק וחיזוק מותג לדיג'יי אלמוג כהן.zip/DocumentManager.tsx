import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { FileText, Plus, Download, Send, CheckCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function DocumentManager() {
  const [selectedType, setSelectedType] = useState<string>("all");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [formData, setFormData] = useState({
    type: "proposal",
    title: "",
    clientName: "",
    clientEmail: "",
    description: "",
  });

  const { data: documents, isLoading, refetch } = trpc.documents.list.useQuery();
  const createDocument = trpc.documents.create.useMutation();
  const updateDocument = trpc.documents.update.useMutation();

  const handleCreateDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createDocument.mutateAsync({
        type: formData.type as any,
        title: formData.title,
        clientName: formData.clientName,
        clientEmail: formData.clientEmail,
        description: formData.description,
      });
      toast.success("טופס נוצר בהצלחה");
      setFormData({ type: "proposal", title: "", clientName: "", clientEmail: "", description: "" });
      setIsCreateOpen(false);
      refetch();
    } catch (error) {
      toast.error("שגיאה בעת יצירת הטופס");
    }
  };

  const handleSendForSignature = async (documentId: number, clientEmail: string) => {
    try {
      await updateDocument.mutateAsync({
        id: documentId,
        status: "sent",
        sentAt: new Date(),
      });
      toast.success(`טופס נשלח ל-${clientEmail}`);
      refetch();
    } catch (error) {
      toast.error("שגיאה בשליחת הטופס");
    }
  };

  const filteredDocuments = documents?.filter((doc) =>
    selectedType === "all" ? true : doc.type === selectedType
  ) || [];

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; color: string }> = {
      draft: { label: "טיוטה", color: "bg-gray-100 text-gray-800" },
      generated: { label: "נוצר", color: "bg-blue-100 text-blue-800" },
      sent: { label: "נשלח", color: "bg-yellow-100 text-yellow-800" },
      viewed: { label: "נצפה", color: "bg-purple-100 text-purple-800" },
      signed: { label: "חתום", color: "bg-green-100 text-green-800" },
      paid: { label: "שולם", color: "bg-emerald-100 text-emerald-800" },
      archived: { label: "בארכיון", color: "bg-gray-300 text-gray-900" },
    };
    const info = statusMap[status] || { label: status, color: "bg-gray-100" };
    return <span className={`px-3 py-1 rounded-full text-xs font-medium ${info.color}`}>{info.label}</span>;
  };

  const getTypeLabel = (type: string) => {
    const typeMap: Record<string, string> = {
      proposal: "הצעה",
      contract: "חוזה",
      invoice: "חשבונית",
      receipt: "קבלה",
      course_material: "חומר קורס",
      other: "אחר",
    };
    return typeMap[type] || type;
  };

  return (
    <div className="space-y-8 p-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">ניהול טפסים וחוזים</h1>
          <p className="text-gray-600 mt-2">צור, שלח וחתום על טפסים דיגיטליים</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#059cc0] hover:bg-[#03b28c]">
              <Plus className="w-4 h-4 mr-2" />
              טופס חדש
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>יצירת טופס חדש</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateDocument} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">סוג הטופס</label>
                <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="proposal">הצעה</SelectItem>
                    <SelectItem value="contract">חוזה</SelectItem>
                    <SelectItem value="invoice">חשבונית</SelectItem>
                    <SelectItem value="receipt">קבלה</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">כותרת</label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="כותרת הטופס"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">שם הלקוח</label>
                <Input
                  value={formData.clientName}
                  onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                  placeholder="שם הלקוח"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">דואל הלקוח</label>
                <Input
                  type="email"
                  value={formData.clientEmail}
                  onChange={(e) => setFormData({ ...formData, clientEmail: e.target.value })}
                  placeholder="דואל הלקוח"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">תיאור</label>
                <Input
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="תיאור קצר"
                />
              </div>
              <Button type="submit" className="w-full bg-[#059cc0]">
                יצור טופס
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <Select value={selectedType} onValueChange={setSelectedType}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל הטפסים</SelectItem>
            <SelectItem value="proposal">הצעות</SelectItem>
            <SelectItem value="contract">חוזים</SelectItem>
            <SelectItem value="invoice">חשבוניות</SelectItem>
            <SelectItem value="receipt">קבלות</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Documents List */}
      <div className="grid gap-4">
        {isLoading ? (
          <div className="text-center py-8">טוען...</div>
        ) : filteredDocuments.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <FileText className="w-12 h-12 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">אין טפסים עדיין</p>
            </CardContent>
          </Card>
        ) : (
          filteredDocuments.map((doc) => (
            <Card key={doc.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <FileText className="w-5 h-5 text-[#059cc0]" />
                      <h3 className="font-semibold text-lg">{doc.title}</h3>
                      {getStatusBadge(doc.status)}
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{getTypeLabel(doc.type)}</p>
                    {doc.clientName && <p className="text-sm text-gray-700">לקוח: {doc.clientName}</p>}
                    {doc.clientEmail && <p className="text-sm text-gray-700">דואל: {doc.clientEmail}</p>}
                    {doc.description && <p className="text-sm text-gray-600 mt-2">{doc.description}</p>}
                  </div>
                  <div className="flex gap-2 ml-4">
                    {doc.status === "draft" && doc.clientEmail && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleSendForSignature(doc.id, doc.clientEmail!)}
                        className="border-[#059cc0] text-[#059cc0]"
                      >
                        <Send className="w-4 h-4 mr-1" />
                        שלח
                      </Button>
                    )}
                    {doc.status === "signed" && (
                      <Button size="sm" variant="outline" className="border-green-500 text-green-600">
                        <CheckCircle className="w-4 h-4 mr-1" />
                        חתום
                      </Button>
                    )}
                    {doc.fileUrl && (
                      <Button size="sm" variant="outline" className="border-[#03b28c] text-[#03b28c]">
                        <Download className="w-4 h-4 mr-1" />
                        הורד
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
