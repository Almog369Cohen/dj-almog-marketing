import React, { useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CheckCircle, RotateCcw } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface SignatureWidgetProps {
  documentId: number;
  onSignatureComplete?: () => void;
}

export default function SignatureWidget({ documentId, onSignatureComplete }: SignatureWidgetProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [signerName, setSignerName] = useState("");
  const [signerEmail, setSignerEmail] = useState("");
  const [isSigning, setIsSigning] = useState(false);

  const createSignature = trpc.signatures.create.useMutation();
  const updateDocument = trpc.documents.update.useMutation();

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    setIsDrawing(true);
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.lineWidth = 2;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = "#059cc0";
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearSignature = () => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  const handleSign = async () => {
    if (!signerName.trim()) {
      toast.error("אנא הזן את שמך");
      return;
    }

    if (!canvasRef.current) return;

    try {
      setIsSigning(true);
      const signatureImage = canvasRef.current.toDataURL("image/png");

      // Create signature record
      await createSignature.mutateAsync({
        documentId,
        signerName,
        signerEmail: signerEmail || undefined,
        signatureImage,
      });

      // Update document status
      await updateDocument.mutateAsync({
        id: documentId,
        status: "signed",
        signedAt: new Date(),
      });

      toast.success("החתימה נשמרה בהצלחה!");
      onSignatureComplete?.();
    } catch (error) {
      toast.error("שגיאה בשמירת החתימה");
    } finally {
      setIsSigning(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>חתום על המסמך</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Signer Info */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">שמך המלא</label>
              <Input
                value={signerName}
                onChange={(e) => setSignerName(e.target.value)}
                placeholder="הזן את שמך"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">דואל (אופציונלי)</label>
              <Input
                type="email"
                value={signerEmail}
                onChange={(e) => setSignerEmail(e.target.value)}
                placeholder="דואלך"
              />
            </div>
          </div>

          {/* Signature Canvas */}
          <div>
            <label className="block text-sm font-medium mb-2">חתימה</label>
            <p className="text-xs text-gray-500 mb-2">חתום בעכבר או בטאצ׳ סקרין</p>
            <canvas
              ref={canvasRef}
              width={500}
              height={200}
              onMouseDown={startDrawing}
              onMouseMove={draw}
              onMouseUp={stopDrawing}
              onMouseLeave={stopDrawing}
              className="border-2 border-dashed border-gray-300 rounded-lg bg-white cursor-crosshair w-full"
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              onClick={clearSignature}
              variant="outline"
              className="flex-1"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              נקה
            </Button>
            <Button
              onClick={handleSign}
              disabled={isSigning || !signerName.trim()}
              className="flex-1 bg-[#059cc0] hover:bg-[#03b28c]"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              {isSigning ? "שומר..." : "שלח חתימה"}
            </Button>
          </div>

          {/* Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-900">
              ✓ החתימה שלך תאומת בעזרת כתובת ה-IP וה-User Agent שלך
            </p>
            <p className="text-sm text-blue-900 mt-2">
              ✓ כל המידע מוצפן ובטוח
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
