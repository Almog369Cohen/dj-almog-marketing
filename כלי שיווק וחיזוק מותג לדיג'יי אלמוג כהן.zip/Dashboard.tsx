import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Users, TrendingUp, MessageSquare, Target } from "lucide-react";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();

  if (!user) return null;

  const COLORS = ['#059cc0', '#03b28c', '#1f1f21', '#ffffff'];

  // Mock data for charts
  const engagementData = [
    { name: 'שבוע 1', likes: 120, comments: 30, shares: 20 },
    { name: 'שבוע 2', likes: 200, comments: 50, shares: 35 },
    { name: 'שבוע 3', likes: 180, comments: 45, shares: 30 },
    { name: 'שבוע 4', likes: 250, comments: 60, shares: 45 },
  ];

  const leadsData = [
    { name: 'חתונות', value: stats?.leads?.weddingLeads || 0 },
    { name: 'קורסי DJ', value: stats?.leads?.courseLeads || 0 },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">ירכז השיווק שלך, {user.name}</h1>
          <p className="text-muted-foreground mt-2">עקוב אחרי ביצועים, לידים ותוכן בזמן אמת</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="border-l-4" style={{ borderLeftColor: '#059cc0' }}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Users className="w-4 h-4" />
                סה"כ לידים
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <div className="text-2xl font-bold">{stats?.leads?.totalLeads || 0}</div>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                {stats?.leads?.convertedLeads || 0} מומרים
              </p>
            </CardContent>
          </Card>

          <Card className="border-l-4" style={{ borderLeftColor: '#03b28c' }}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Target className="w-4 h-4" />
                לידי חתונה
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <div className="text-2xl font-bold">{stats?.leads?.weddingLeads || 0}</div>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                פעילים כעת
              </p>
            </CardContent>
          </Card>

          <Card className="border-l-4" style={{ borderLeftColor: '#1f1f21' }}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                לידי קורסים
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <div className="text-2xl font-bold">{stats?.leads?.courseLeads || 0}</div>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                פעילים כעת
              </p>
            </CardContent>
          </Card>

          <Card className="border-l-4" style={{ borderLeftColor: '#059cc0' }}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                מתחרים
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <div className="text-2xl font-bold">{stats?.competitorCount || 0}</div>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                תחת ניתוח
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <Tabs defaultValue="engagement" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="engagement">עלויות</TabsTrigger>
            <TabsTrigger value="leads">לידים</TabsTrigger>
            <TabsTrigger value="content">תוכן</TabsTrigger>
          </TabsList>

          <TabsContent value="engagement" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>עלויות השבועות האחרונות</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={engagementData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="likes" stroke="#059cc0" strokeWidth={2} />
                    <Line type="monotone" dataKey="comments" stroke="#03b28c" strokeWidth={2} />
                    <Line type="monotone" dataKey="shares" stroke="#1f1f21" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="leads" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>חלוקת לידים</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={leadsData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {leadsData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="content" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>תוכן אחרון</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : stats?.recentContent && stats.recentContent.length > 0 ? (
                  <div className="space-y-3">
                    {stats.recentContent.slice(0, 5).map((content) => (
                      <div key={content.id} className="p-3 border rounded-lg">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-medium">{content.title}</p>
                            <p className="text-sm text-muted-foreground">
                              {content.pillar} • {content.platform}
                            </p>
                          </div>
                          <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800">
                            {content.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground">אין תוכן עדיין</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
