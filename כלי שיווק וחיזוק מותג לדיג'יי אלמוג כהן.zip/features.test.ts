import { describe, it, expect, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import type { User } from "../drizzle/schema";

// Mock user for testing
const mockUser: User = {
  id: 1,
  openId: "test-user-123",
  email: "test@example.com",
  name: "Test User",
  loginMethod: "manus",
  role: "user",
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

// Mock context
function createMockContext(): TrpcContext {
  return {
    user: mockUser,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("tRPC Routers", () => {
  describe("dashboard.stats", () => {
    it("returns dashboard statistics for authenticated user", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const stats = await caller.dashboard.stats();

      expect(stats).toBeDefined();
      expect(stats).toHaveProperty("leads");
      expect(stats).toHaveProperty("engagement");
      expect(stats).toHaveProperty("recentContent");
      expect(stats).toHaveProperty("competitorCount");
    });

    it("returns valid lead statistics structure", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const stats = await caller.dashboard.stats();

      if (stats.leads) {
        expect(stats.leads).toHaveProperty("totalLeads");
        expect(stats.leads).toHaveProperty("weddingLeads");
        expect(stats.leads).toHaveProperty("courseLeads");
        expect(stats.leads).toHaveProperty("convertedLeads");
        expect(typeof stats.leads.totalLeads).toBe("number");
      }
    });
  });

  describe("brand.getSettings", () => {
    it("returns brand settings or undefined", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const settings = await caller.brand.getSettings();

      // Settings may be undefined if not set, or an object if set
      expect(settings === undefined || typeof settings === "object").toBe(true);
    });
  });

  describe("brand.updateSettings", () => {
    it("updates brand settings with provided values", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.brand.updateSettings({
        primaryColor: "#059cc0",
        secondaryColor: "#03b28c",
        toneOfVoice: "Professional and energetic",
      });

      expect(result).toEqual({ success: true });
    });

    it("allows partial updates", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.brand.updateSettings({
        primaryColor: "#ff0000",
      });

      expect(result).toEqual({ success: true });
    });
  });

  describe("content.list", () => {
    it("returns array of content for user", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const content = await caller.content.list();

      expect(Array.isArray(content)).toBe(true);
      // Content may exist from previous test runs
      expect(content.length).toBeGreaterThanOrEqual(0);
    });
  });

  describe("content.create", () => {
    it("creates new content plan with valid input", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.content.create({
        title: "Test Content " + Date.now(),
        description: "Test description",
        pillar: "authority",
        platform: "instagram_reel",
        content: "Test content",
        hooks: "Test hooks",
        captions: "Test captions",
        hashtags: "#test",
      });

      expect(result).toBeDefined();
    });

    it("validates required fields", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.content.create({
          title: "",
          pillar: "authority",
          platform: "instagram_reel",
        } as any);
        expect.fail("Should have thrown validation error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("leads.list", () => {
    it("returns array of leads for user", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const leads = await caller.leads.list({});

      expect(Array.isArray(leads)).toBe(true);
      // Leads may exist from previous test runs
      expect(leads.length).toBeGreaterThanOrEqual(0);
    });

    it("filters leads by type", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const weddingLeads = await caller.leads.list({ type: "wedding" });
      const courseLeads = await caller.leads.list({ type: "dj_course" });

      expect(Array.isArray(weddingLeads)).toBe(true);
      expect(Array.isArray(courseLeads)).toBe(true);
      // Both should be arrays, regardless of content
      expect(weddingLeads.length).toBeGreaterThanOrEqual(0);
      expect(courseLeads.length).toBeGreaterThanOrEqual(0);
    });
  });

  describe("leads.create", () => {
    it("creates new wedding lead", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.leads.create({
        name: "John Doe " + Date.now(),
        email: "john" + Date.now() + "@example.com",
        phone: "+972-50-1234567",
        type: "wedding",
        source: "instagram",
        notes: "Interested in wedding DJ",
      });

      expect(result).toBeDefined();
    });

    it("creates new DJ course lead", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.leads.create({
        name: "Jane Smith " + Date.now(),
        type: "dj_course",
        source: "website",
      });

      expect(result).toBeDefined();
    });

    it("validates required fields", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.leads.create({
          name: "",
          type: "wedding",
          source: "instagram",
        } as any);
        expect.fail("Should have thrown validation error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("competitors.list", () => {
    it("returns array of competitors for user", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const competitors = await caller.competitors.list();

      expect(Array.isArray(competitors)).toBe(true);
      // Competitors may exist from previous test runs
      expect(competitors.length).toBeGreaterThanOrEqual(0);
    });
  });

  describe("competitors.create", () => {
    it("creates new competitor entry", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.competitors.create({
        name: "DJ Competitor " + Date.now(),
        instagramHandle: "@dj_competitor_" + Date.now(),
        website: "https://djcompetitor" + Date.now() + ".com",
        specialization: "Weddings",
        mainMessages: "Professional wedding DJ",
        targetAudience: "Couples",
      });

      expect(result).toBeDefined();
    });

    it("validates required name field", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.competitors.create({
          name: "",
          instagramHandle: "@test",
        } as any);
        expect.fail("Should have thrown validation error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });
});
