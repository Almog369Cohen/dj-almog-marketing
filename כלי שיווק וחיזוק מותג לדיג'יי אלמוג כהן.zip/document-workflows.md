# Document Workflows & Management

## Document Types Overview

### 1. Proposals & Quotes
**Purpose**: Present pricing and services to potential clients
**Trigger**: Lead requests pricing or information
**Recipient**: Potential client
**Action**: Client reviews and decides to proceed

**Template Fields:**
- Business name and logo
- Client name and contact info
- Event/service details
- Service packages and pricing
- Terms and conditions
- Valid until date
- Signature line for client
- Signature line for business owner

**Example Proposal Flow:**
```
Lead: "How much for a wedding DJ?"
↓
Business: Creates proposal with pricing
↓
Proposal sent via email with e-signature link
↓
Client reviews proposal
↓
Client signs proposal (acceptance)
↓
Proposal marked as "Accepted"
↓
Contract automatically generated
```

### 2. Contracts
**Purpose**: Legally binding agreement between parties
**Trigger**: After proposal acceptance or direct booking
**Recipient**: Client
**Action**: Client signs to confirm booking

**Contract Types:**

#### Wedding DJ Contract
- Event date and time
- Venue information
- Services included
- Pricing and payment terms
- Cancellation policy
- Equipment and technical requirements
- Timeline and setup requirements
- Client responsibilities
- Liability and insurance
- Signatures of both parties

#### Event DJ Contract
- Event type and date
- Venue and contact
- Duration of service
- Pricing breakdown
- Payment schedule
- Cancellation/rescheduling policy
- Technical requirements
- Backup plan
- Signatures

#### Course Enrollment Agreement
- Course name and duration
- Student name and contact
- Course fees
- Payment schedule
- Refund policy
- Course materials and access
- Student responsibilities
- Attendance requirements
- Certification terms
- Signatures

#### Collaboration Agreement
- Project description
- Parties involved
- Roles and responsibilities
- Revenue/payment split
- Timeline
- Intellectual property rights
- Confidentiality
- Dispute resolution
- Signatures

### 3. Invoices & Receipts
**Purpose**: Request payment and track transactions
**Trigger**: After contract signed or service delivered
**Recipient**: Client
**Action**: Client pays invoice

**Invoice Fields:**
- Invoice number (unique ID)
- Invoice date
- Due date
- Business details
- Client details
- Service description
- Amount
- Payment methods accepted
- Payment instructions
- Terms (Net 15, Net 30, etc.)

**Receipt Fields:**
- Receipt number
- Date
- Client name
- Service/product description
- Amount paid
- Payment method
- Thank you message

### 4. Course Materials
**Purpose**: Deliver educational content
**Trigger**: After student enrollment
**Recipient**: Student
**Action**: Student accesses and completes materials

**Types:**
- Course syllabus
- Lesson materials (PDFs, videos)
- Assignments and projects
- Resources and references
- Certificate of completion

### 5. Administrative Documents
**Purpose**: Confirmation and follow-up
**Trigger**: Various points in customer journey
**Recipient**: Client
**Action**: Confirmation, reminder, or feedback

**Types:**
- Booking confirmation
- Payment confirmation
- Thank you letter
- Follow-up survey
- Referral request

## Document Generation Workflow

### Step 1: Trigger
Document generation is triggered by:
- Manual request from business owner
- Automatic trigger (e.g., after lead status change)
- Scheduled trigger (e.g., invoice on specific date)

### Step 2: Data Collection
Gather required information:
- Client information (from lead database)
- Service details (from lead notes or form)
- Pricing (from service catalog)
- Business branding (from brand settings)
- Custom fields (from form input)

### Step 3: Template Selection
Choose appropriate template based on:
- Document type
- Client type (wedding, course, event, etc.)
- Business branding
- Language preference

### Step 4: Merge Fields
Replace template placeholders with actual data:
```html
<p>Dear {{client_name}},</p>
<p>Thank you for choosing {{business_name}}.</p>
<p>Event Date: {{event_date}}</p>
<p>Total Price: {{total_price}}</p>
```

### Step 5: PDF Generation
Convert HTML/template to PDF:
- Apply branding colors
- Embed images/logo
- Format for printing
- Add page numbers if needed

### Step 6: Storage
Save generated document:
- Store in database with metadata
- Link to client/lead record
- Create audit trail
- Set access permissions

### Step 7: Delivery
Send document to client:
- Email with attachment
- E-signature link (for contracts/proposals)
- Direct download link
- SMS notification

## E-Signature Integration

### Workflow: Proposal to Signed Contract

```
1. Business creates proposal
   └─ Fills in client info, pricing, terms
   
2. Proposal generated as PDF
   └─ Applied branding, formatted for signature
   
3. E-signature request created
   └─ Signature fields added to PDF
   └─ Unique signing link generated
   
4. Email sent to client
   └─ Link to review and sign proposal
   └─ Deadline for signature
   
5. Client opens link
   └─ Reviews proposal
   └─ Enters name and signature
   └─ Confirms signature
   
6. Signature captured
   └─ Timestamp recorded
   └─ IP address logged
   └─ Signed PDF generated
   
7. Document stored
   └─ Signed PDF saved to database
   └─ Linked to lead record
   └─ Status updated to "Signed"
   
8. Business notified
   └─ Automatic email to business owner
   └─ Notification in dashboard
   
9. Follow-up triggered
   └─ Contract automatically generated
   └─ Invoice created
   └─ Next steps initiated
```

### Implementation Options

#### Option 1: DocuSign Integration
**Pros:**
- Professional, widely recognized
- Advanced features (multiple signers, fields)
- Audit trail and compliance
- Mobile-friendly

**Cons:**
- Cost per signature
- External dependency
- Setup complexity

**Implementation:**
```python
from docusign_esign import ApiClient, EnvelopesApi

# Create envelope with document
# Add signature fields
# Send for signature
# Webhook receives completion notification
```

#### Option 2: HelloSign Integration
**Pros:**
- Simple API
- Affordable pricing
- Good documentation
- White-label options

**Cons:**
- Limited customization
- Fewer advanced features

**Implementation:**
```python
import hellosign_sdk

# Upload document
# Add signature fields
# Send for signature
# Receive signed document
```

#### Option 3: Custom Implementation
**Pros:**
- Full control
- No per-signature costs
- Customizable workflow

**Cons:**
- Legal compliance responsibility
- More development work
- Security considerations

**Implementation:**
```typescript
// Capture signature using canvas/digital pen
// Store signature image with timestamp
// Link to document
// Generate audit trail
```

## Database Schema for Documents

```sql
CREATE TABLE documents (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  leadId INT,
  type ENUM('proposal', 'contract', 'invoice', 'receipt', 'course_material', 'other'),
  title VARCHAR(255),
  description TEXT,
  templateId INT,
  status ENUM('draft', 'generated', 'sent', 'viewed', 'signed', 'paid', 'archived'),
  clientName VARCHAR(255),
  clientEmail VARCHAR(320),
  fileUrl VARCHAR(255),
  fileKey VARCHAR(255),
  generatedAt TIMESTAMP,
  sentAt TIMESTAMP,
  viewedAt TIMESTAMP,
  signedAt TIMESTAMP,
  paidAt TIMESTAMP,
  createdAt TIMESTAMP DEFAULT NOW(),
  updatedAt TIMESTAMP DEFAULT NOW() ON UPDATE NOW()
);

CREATE TABLE signatures (
  id INT PRIMARY KEY AUTO_INCREMENT,
  documentId INT NOT NULL,
  signerName VARCHAR(255),
  signerEmail VARCHAR(320),
  signatureImage LONGBLOB,
  signedAt TIMESTAMP,
  ipAddress VARCHAR(45),
  userAgent TEXT,
  createdAt TIMESTAMP DEFAULT NOW()
);

CREATE TABLE invoices (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  leadId INT,
  documentId INT,
  invoiceNumber VARCHAR(50) UNIQUE,
  clientName VARCHAR(255),
  clientEmail VARCHAR(320),
  amount DECIMAL(10, 2),
  currency VARCHAR(3) DEFAULT 'USD',
  status ENUM('draft', 'sent', 'viewed', 'paid', 'overdue', 'cancelled'),
  dueDate DATE,
  paidDate DATE,
  paymentMethod VARCHAR(50),
  notes TEXT,
  createdAt TIMESTAMP DEFAULT NOW(),
  updatedAt TIMESTAMP DEFAULT NOW() ON UPDATE NOW()
);
```

## tRPC Procedures for Documents

```typescript
// Create document from template
documents: router({
  generate: protectedProcedure
    .input(z.object({
      type: z.enum(['proposal', 'contract', 'invoice', ...]),
      leadId: z.number(),
      data: z.record(z.any()),
    }))
    .mutation(async ({ ctx, input }) => {
      // Generate PDF from template
      // Store in database
      // Return document URL
    }),
  
  // Send document for signature
  sendForSignature: protectedProcedure
    .input(z.object({
      documentId: z.number(),
      clientEmail: z.string().email(),
    }))
    .mutation(async ({ ctx, input }) => {
      // Create e-signature request
      // Send email to client
      // Return signing link
    }),
  
  // Record signature
  recordSignature: protectedProcedure
    .input(z.object({
      documentId: z.number(),
      signatureImage: z.string(),
      signerName: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      // Store signature
      // Update document status
      // Trigger follow-up workflows
    }),
}),
```

## Best Practices

1. **Always use templates** - Consistency and efficiency
2. **Keep documents organized** - Link to leads/clients
3. **Maintain audit trail** - Track all changes and signatures
4. **Use version control** - Keep template versions
5. **Test before sending** - Generate test documents first
6. **Backup documents** - Store in multiple locations
7. **Respect privacy** - Secure document storage
8. **Follow legal requirements** - Ensure compliance
