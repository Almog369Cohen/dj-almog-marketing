import { and, count, eq, gte, sql, sum } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  brandSettings,
  contentPlans,
  leads,
  competitors,
  contentAnalytics,
} from "../drizzle/schema";
import type {
  InsertBrandSettings,
  InsertCompetitor,
  InsertContentAnalytic,
  InsertContentPlan,
  InsertLead,
} from "../drizzle/schema";

/**
 * Music Business Hub - Database Helpers Template
 * 
 * This template provides reusable database query functions.
 * Customize queries based on your specific business logic.
 */

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ Brand Settings ============

export async function getBrandSettings(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(brandSettings).where(eq(brandSettings.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertBrandSettings(userId: number, data: Partial<InsertBrandSettings>) {
  const db = await getDb();
  if (!db) return;
  await db.insert(brandSettings).values({ userId, ...data }).onDuplicateKeyUpdate({
    set: data,
  });
}

// ============ Content Plans ============

export async function getContentPlans(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contentPlans).where(eq(contentPlans.userId, userId)).limit(limit);
}

export async function createContentPlan(userId: number, data: Omit<InsertContentPlan, 'userId'>) {
  const db = await getDb();
  if (!db) return;
  return db.insert(contentPlans).values({ userId, ...data });
}

// ============ Leads ============

export async function getLeads(userId: number, type?: string) {
  const db = await getDb();
  if (!db) return [];
  if (type) {
    return db.select().from(leads).where(and(eq(leads.userId, userId), eq(leads.type, type as any)));
  }
  return db.select().from(leads).where(eq(leads.userId, userId));
}

export async function createLead(userId: number, data: Omit<InsertLead, 'userId'>) {
  const db = await getDb();
  if (!db) return;
  return db.insert(leads).values({ userId, ...data });
}

export async function getLeadStats(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select({
    totalLeads: count(),
    weddingLeads: count(sql`CASE WHEN type = 'wedding' THEN 1 END`),
    courseLeads: count(sql`CASE WHEN type = 'dj_course' THEN 1 END`),
    convertedLeads: count(sql`CASE WHEN status = 'converted' THEN 1 END`),
  }).from(leads).where(eq(leads.userId, userId));
  return result[0];
}

// ============ Competitors ============

export async function getCompetitors(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(competitors).where(eq(competitors.userId, userId));
}

export async function createCompetitor(userId: number, data: Omit<InsertCompetitor, 'userId'>) {
  const db = await getDb();
  if (!db) return;
  return db.insert(competitors).values({ userId, ...data });
}

// ============ Content Analytics ============

export async function getContentAnalytics(userId: number, days = 30) {
  const db = await getDb();
  if (!db) return [];
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  return db.select().from(contentAnalytics).where(
    and(eq(contentAnalytics.userId, userId), gte(contentAnalytics.recordedAt, since))
  );
}

export async function getEngagementStats(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select({
    totalLikes: sum(contentAnalytics.likes),
    totalComments: sum(contentAnalytics.comments),
    totalShares: sum(contentAnalytics.shares),
    totalSaves: sum(contentAnalytics.saves),
    totalReach: sum(contentAnalytics.reach),
    totalImpressions: sum(contentAnalytics.impressions),
    totalLeadsGenerated: sum(contentAnalytics.leadsGenerated),
  }).from(contentAnalytics).where(eq(contentAnalytics.userId, userId));
  return result[0];
}

export async function recordContentAnalytic(userId: number, data: Omit<InsertContentAnalytic, 'userId'>) {
  const db = await getDb();
  if (!db) return;
  return db.insert(contentAnalytics).values({ userId, ...data });
}
