import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { FileText, Plus, Send, CheckCircle, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function InvoiceManager() {
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [formData, setFormData] = useState({
    invoiceNumber: "",
    clientName: "",
    clientEmail: "",
    amount: "",
    currency: "ILS",
    dueDate: "",
    notes: "",
  });

  const { data: invoices, isLoading, refetch } = trpc.invoices.list.useQuery();
  const createInvoice = trpc.invoices.create.useMutation();
  const updateInvoice = trpc.invoices.update.useMutation();

  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (!formData.invoiceNumber || !formData.clientName || !formData.amount) {
        toast.error("אנא מלא את כל השדות החובה");
        return;
      }

      await createInvoice.mutateAsync({
        invoiceNumber: formData.invoiceNumber,
        clientName: formData.clientName,
        clientEmail: formData.clientEmail || undefined,
        amount: parseInt(formData.amount) * 100,
        currency: formData.currency,
        dueDate: formData.dueDate ? new Date(formData.dueDate) : undefined,
        notes: formData.notes || undefined,
      });

      toast.success("חשבונית נוצרה בהצלחה");
      setFormData({
        invoiceNumber: "",
        clientName: "",
        clientEmail: "",
        amount: "",
        currency: "ILS",
        dueDate: "",
        notes: "",
      });
      setIsCreateOpen(false);
      refetch();
    } catch (error) {
      toast.error("שגיאה בעת יצירת החשבונית");
    }
  };

  const handleSendInvoice = async (invoiceId: number, clientEmail: string) => {
    try {
      await updateInvoice.mutateAsync({
        id: invoiceId,
        status: "sent",
      });
      toast.success(`חשבונית נשלחה ל-${clientEmail}`);
      refetch();
    } catch (error) {
      toast.error("שגיאה בשליחת החשבונית");
    }
  };

  const handleMarkAsPaid = async (invoiceId: number) => {
    try {
      await updateInvoice.mutateAsync({
        id: invoiceId,
        status: "paid",
        paidDate: new Date(),
      });
      toast.success("החשבונית סומנה כשולמה");
      refetch();
    } catch (error) {
      toast.error("שגיאה בעדכון החשבונית");
    }
  };

  const filteredInvoices = invoices?.filter((inv) =>
    selectedStatus === "all" ? true : inv.status === selectedStatus
  ) || [];

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; color: string }> = {
      draft: { label: "טיוטה", color: "bg-gray-100 text-gray-800" },
      sent: { label: "נשלחה", color: "bg-yellow-100 text-yellow-800" },
      viewed: { label: "נצפתה", color: "bg-blue-100 text-blue-800" },
      paid: { label: "שולמה", color: "bg-green-100 text-green-800" },
      overdue: { label: "逾期", color: "bg-red-100 text-red-800" },
      cancelled: { label: "בוטלה", color: "bg-gray-300 text-gray-900" },
    };
    const info = statusMap[status] || { label: status, color: "bg-gray-100" };
    return <span className={`px-3 py-1 rounded-full text-xs font-medium ${info.color}`}>{info.label}</span>;
  };

  const formatAmount = (amount: number) => {
    return (amount / 100).toLocaleString("he-IL", {
      style: "currency",
      currency: "ILS",
    });
  };

  const totalRevenue = filteredInvoices
    .filter((inv) => inv.status === "paid")
    .reduce((sum, inv) => sum + inv.amount, 0);

  const pendingAmount = filteredInvoices
    .filter((inv) => inv.status !== "paid" && inv.status !== "cancelled")
    .reduce((sum, inv) => sum + inv.amount, 0);

  return (
    <div className="space-y-8 p-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">ניהול חשבוניות</h1>
          <p className="text-gray-600 mt-2">צור, שלח וקבל תשלומים</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#059cc0] hover:bg-[#03b28c]">
              <Plus className="w-4 h-4 mr-2" />
              חשבונית חדשה
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>יצירת חשבונית חדשה</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateInvoice} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">מספר חשבונית</label>
                <Input
                  value={formData.invoiceNumber}
                  onChange={(e) => setFormData({ ...formData, invoiceNumber: e.target.value })}
                  placeholder="למ״ד 001"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">שם הלקוח</label>
                <Input
                  value={formData.clientName}
                  onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                  placeholder="שם הלקוח"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">דואל הלקוח</label>
                <Input
                  type="email"
                  value={formData.clientEmail}
                  onChange={(e) => setFormData({ ...formData, clientEmail: e.target.value })}
                  placeholder="דואל הלקוח"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">סכום</label>
                  <Input
                    type="number"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    placeholder="0"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">מטבע</label>
                  <Select value={formData.currency} onValueChange={(value) => setFormData({ ...formData, currency: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ILS">שקל</SelectItem>
                      <SelectItem value="USD">דולר</SelectItem>
                      <SelectItem value="EUR">יורו</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">תאריך תשלום</label>
                <Input
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">הערות</label>
                <Input
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="הערות אופציונליות"
                />
              </div>
              <Button type="submit" className="w-full bg-[#059cc0]">
                צור חשבונית
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">הכנסות שולמו</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {formatAmount(totalRevenue)}
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-yellow-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">בהמתנה לתשלום</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {formatAmount(pendingAmount)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <Select value={selectedStatus} onValueChange={setSelectedStatus}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל החשבוניות</SelectItem>
            <SelectItem value="draft">טיוטה</SelectItem>
            <SelectItem value="sent">נשלחה</SelectItem>
            <SelectItem value="paid">שולמה</SelectItem>
            <SelectItem value="overdue">逾期</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Invoices List */}
      <div className="grid gap-4">
        {isLoading ? (
          <div className="text-center py-8">טוען...</div>
        ) : filteredInvoices.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <FileText className="w-12 h-12 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">אין חשבוניות עדיין</p>
            </CardContent>
          </Card>
        ) : (
          filteredInvoices.map((invoice) => (
            <Card key={invoice.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <FileText className="w-5 h-5 text-[#059cc0]" />
                      <h3 className="font-semibold text-lg">חשבונית {invoice.invoiceNumber}</h3>
                      {getStatusBadge(invoice.status)}
                    </div>
                    <p className="text-sm text-gray-600 mb-2">לקוח: {invoice.clientName}</p>
                    {invoice.clientEmail && <p className="text-sm text-gray-600">דואל: {invoice.clientEmail}</p>}
                    <p className="text-lg font-bold text-gray-900 mt-2">
                      {formatAmount(invoice.amount)}
                    </p>
                    {invoice.dueDate && (
                      <p className="text-sm text-gray-500 mt-1">
                        תאריך תשלום: {new Date(invoice.dueDate).toLocaleDateString("he-IL")}
                      </p>
                    )}
                    {invoice.notes && <p className="text-sm text-gray-600 mt-2">{invoice.notes}</p>}
                  </div>
                  <div className="flex gap-2 ml-4">
                    {invoice.status === "draft" && invoice.clientEmail && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleSendInvoice(invoice.id, invoice.clientEmail!)}
                        className="border-[#059cc0] text-[#059cc0]"
                      >
                        <Send className="w-4 h-4 mr-1" />
                        שלח
                      </Button>
                    )}
                    {invoice.status !== "paid" && invoice.status !== "cancelled" && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleMarkAsPaid(invoice.id)}
                        className="border-green-500 text-green-600"
                      >
                        <CheckCircle className="w-4 h-4 mr-1" />
                        שולם
                      </Button>
                    )}
                    {invoice.status === "overdue" && (
                      <Button size="sm" variant="outline" className="border-red-500 text-red-600" disabled>
                        <AlertCircle className="w-4 h-4 mr-1" />
                        逾期
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
