# Music Business Hub - Implementation Guide

## Overview

This guide walks through implementing a comprehensive music business management platform with dashboard, content planning, lead management, and competitor analysis.

## Architecture Overview

```
Frontend (React 19 + Tailwind 4)
  ├── Dashboard (real-time stats)
  ├── Content Planner (4-pillar system)
  ├── Lead Manager (wedding + courses)
  ├── Competitor Analysis
  └── Brand Settings

Backend (Express + tRPC)
  ├── Dashboard Router (stats queries)
  ├── Brand Router (settings management)
  ├── Content Router (CRUD operations)
  ├── Leads Router (lead management)
  ├── Competitors Router (competitor tracking)
  └── Analytics Router (performance metrics)

Database (MySQL/TiDB)
  ├── brand_settings
  ├── content_plans
  ├── leads
  ├── competitors
  ├── content_templates
  └── content_analytics
```

## Step-by-Step Implementation

### 1. Database Setup

1. Copy `drizzle-schema-template.ts` to `drizzle/schema.ts`
2. Customize table names and fields as needed
3. Run `pnpm drizzle-kit generate` to create migrations
4. Apply migrations via `webdev_execute_sql`

**Key Customization Points:**
- Add/remove lead types (wedding, dj_course, event, etc.)
- Adjust content pillars (authority, energy, mentor, person)
- Add platform-specific fields (TikTok, YouTube, etc.)

### 2. Backend Setup

1. Copy `db-helpers-template.ts` to `server/db.ts`
2. Copy `trpc-routers-template.ts` to `server/routers.ts`
3. Update imports to match your project structure
4. Test with `pnpm test`

**Key Customization Points:**
- Add business-specific queries in db.ts
- Add validation rules in tRPC input schemas
- Add authorization checks in protected procedures

### 3. Frontend Setup

Create these pages in `client/src/pages/`:

- **Dashboard.tsx** - Overview with key metrics
- **ContentPlanner.tsx** - Monthly content planning
- **LeadsManager.tsx** - Lead tracking and management
- **CompetitorAnalysis.tsx** - Competitor tracking
- **BrandSettings.tsx** - Brand identity management

**Key Customization Points:**
- Adjust color scheme (primary, secondary, accent colors)
- Add language support (Hebrew, Arabic, etc.)
- Customize chart types and metrics
- Add export/reporting features

### 4. Styling & Branding

**Color Scheme:**
```css
--primary: #059cc0    /* Teal */
--secondary: #03b28c  /* Green */
--accent: #1f1f21     /* Dark */
--background: #ffffff /* White */
```

**Typography:**
- Use system fonts or Google Fonts
- Ensure RTL support for Hebrew/Arabic
- Test on mobile devices

### 5. Testing

Create tests in `server/features.test.ts`:

```typescript
describe("Dashboard", () => {
  it("returns stats for authenticated user", async () => {
    // Test implementation
  });
});
```

Run tests: `pnpm test`

## Common Customizations

### Add New Lead Type

1. Update `leads` table enum: `mysqlEnum("type", [..., "new_type"])`
2. Generate migration: `pnpm drizzle-kit generate`
3. Apply migration: `webdev_execute_sql`
4. Update tRPC input schema
5. Update UI components

### Add New Content Platform

1. Update `contentPlans` table: `mysqlEnum("platform", [..., "tiktok_video"])`
2. Generate and apply migration
3. Update tRPC schema
4. Update Content Planner UI

### Add Custom Analytics Metric

1. Add column to `contentAnalytics` table
2. Generate and apply migration
3. Update `recordContentAnalytic` function
4. Update Analytics dashboard

### Support Multiple Languages

1. Create i18n configuration
2. Add language strings to database or constants
3. Use `useTranslation()` hook in components
4. Test RTL layout with Hebrew/Arabic

## Performance Optimization

### Database
- Index frequently queried columns (userId, status, createdAt)
- Use pagination for large result sets
- Cache brand settings in memory

### Frontend
- Use React.memo for chart components
- Implement virtual scrolling for long lists
- Lazy load analytics data

### Backend
- Cache dashboard stats (5-minute TTL)
- Use database connection pooling
- Add query result caching

## Security Considerations

1. **Authentication**: Use Manus OAuth (already configured)
2. **Authorization**: Check userId in all queries
3. **Input Validation**: Use Zod schemas for all inputs
4. **Rate Limiting**: Add rate limits to mutations
5. **Data Privacy**: Encrypt sensitive fields (phone, email)

## Deployment Checklist

- [ ] All tests passing
- [ ] TypeScript compilation succeeds
- [ ] Environment variables configured
- [ ] Database migrations applied
- [ ] Brand colors customized
- [ ] Language support verified
- [ ] Mobile responsiveness tested
- [ ] Performance metrics acceptable

## Troubleshooting

### Navigation Error
**Error**: "Cannot update a component while rendering a different component"
**Fix**: Use `useEffect` for navigation, not during render

### Database Connection
**Error**: "Failed to connect to database"
**Fix**: Check DATABASE_URL environment variable

### tRPC Type Errors
**Error**: "Type 'string' is not assignable to type 'authority' | 'energy' | ..."
**Fix**: Use type assertions: `as 'authority' | 'energy' | ...`

## Next Steps

1. Implement Instagram API integration for real analytics
2. Add email notifications for new leads
3. Create automated content suggestions based on competitors
4. Build export/reporting features
5. Add team collaboration features
