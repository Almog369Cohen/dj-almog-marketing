import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  dashboard: router({
    stats: protectedProcedure.query(async ({ ctx }) => {
      const [leadStats, engagementStats, recentContent, competitorCount] = await Promise.all([
        db.getLeadStats(ctx.user.id),
        db.getEngagementStats(ctx.user.id),
        db.getContentPlans(ctx.user.id, 10),
        db.getCompetitors(ctx.user.id).then(c => c.length),
      ]);
      return {
        leads: leadStats,
        engagement: engagementStats,
        recentContent,
        competitorCount,
      };
    }),
  }),

  brand: router({
    getSettings: protectedProcedure.query(async ({ ctx }) => {
      return db.getBrandSettings(ctx.user.id);
    }),
    updateSettings: protectedProcedure
      .input(z.object({
        primaryColor: z.string().optional(),
        secondaryColor: z.string().optional(),
        accentColor: z.string().optional(),
        backgroundColor: z.string().optional(),
        toneOfVoice: z.string().optional(),
        brandValues: z.string().optional(),
        brandGuidelines: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.upsertBrandSettings(ctx.user.id, input);
        return { success: true };
      }),
  }),

  content: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getContentPlans(ctx.user.id);
    }),
    create: protectedProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        pillar: z.enum(['authority', 'energy', 'mentor', 'person']),
        platform: z.enum(['instagram_reel', 'instagram_story', 'instagram_post', 'instagram_carousel']),
        content: z.string().optional(),
        hooks: z.string().optional(),
        captions: z.string().optional(),
        hashtags: z.string().optional(),
        scheduledDate: z.date().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createContentPlan(ctx.user.id, input);
      }),
  }),

  leads: router({
    list: protectedProcedure
      .input(z.object({
        type: z.enum(['wedding', 'dj_course']).optional(),
      }))
      .query(async ({ ctx, input }) => {
        return db.getLeads(ctx.user.id, input.type);
      }),
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        type: z.enum(['wedding', 'dj_course']),
        source: z.enum(['instagram', 'website', 'referral', 'direct', 'other']),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createLead(ctx.user.id, input);
      }),
  }),

  competitors: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getCompetitors(ctx.user.id);
    }),
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        instagramHandle: z.string().optional(),
        website: z.string().optional(),
        specialization: z.string().optional(),
        mainMessages: z.string().optional(),
        targetAudience: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createCompetitor(ctx.user.id, input);
      }),
  }),

  documents: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getDocumentsByUserId(ctx.user.id);
    }),
    create: protectedProcedure
      .input(z.object({
        type: z.enum(['proposal', 'contract', 'invoice', 'receipt', 'course_material', 'other']),
        title: z.string(),
        description: z.string().optional(),
        leadId: z.number().optional(),
        clientName: z.string().optional(),
        clientEmail: z.string().email().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createDocument(ctx.user.id, input);
      }),
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getDocumentById(input.id);
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(['draft', 'generated', 'sent', 'viewed', 'signed', 'paid', 'archived']).optional(),
        fileUrl: z.string().optional(),
        fileKey: z.string().optional(),
        sentAt: z.date().optional(),
        viewedAt: z.date().optional(),
        signedAt: z.date().optional(),
        paidAt: z.date().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return db.updateDocument(id, data);
      }),
  }),

  signatures: router({
    getByDocument: protectedProcedure
      .input(z.object({ documentId: z.number() }))
      .query(async ({ input }) => {
        return db.getSignaturesByDocumentId(input.documentId);
      }),
    create: protectedProcedure
      .input(z.object({
        documentId: z.number(),
        signerName: z.string(),
        signerEmail: z.string().email().optional(),
        signatureImage: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createSignature({
          documentId: input.documentId,
          signerName: input.signerName,
          signerEmail: input.signerEmail,
          signatureImage: input.signatureImage,
          ipAddress: (ctx.req.headers['x-forwarded-for'] as string) || 'unknown',
          userAgent: ctx.req.headers['user-agent'] as string,
        });
      }),
  }),

  invoices: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getInvoicesByUserId(ctx.user.id);
    }),
    create: protectedProcedure
      .input(z.object({
        invoiceNumber: z.string(),
        clientName: z.string(),
        clientEmail: z.string().email().optional(),
        amount: z.number(),
        currency: z.string().default('ILS'),
        leadId: z.number().optional(),
        documentId: z.number().optional(),
        dueDate: z.date().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createInvoice(ctx.user.id, input);
      }),
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getInvoiceById(input.id);
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(['draft', 'sent', 'viewed', 'paid', 'overdue', 'cancelled']).optional(),
        paidDate: z.date().optional(),
        paymentMethod: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return db.updateInvoice(id, data);
      }),
  }),
});

export type AppRouter = typeof appRouter;
