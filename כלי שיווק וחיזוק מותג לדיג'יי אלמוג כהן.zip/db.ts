/**
 * Document Templates
 */
export async function getDocumentTemplatesByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(documentTemplates).where(eq(documentTemplates.userId, userId));
}

export async function getDocumentTemplateById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(documentTemplates).where(eq(documentTemplates.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createDocumentTemplate(userId: number, data: Omit<InsertDocumentTemplate, 'userId'>) {
  const db = await getDb();
  if (!db) return;
  return db.insert(documentTemplates).values({ userId, ...data });
}
