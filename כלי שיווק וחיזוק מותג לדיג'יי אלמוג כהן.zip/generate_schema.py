#!/usr/bin/env python3
"""
Music Business Hub - Schema Generation Script

This script helps generate database migrations from the Drizzle schema template.
It provides guidance on the migration process.

Usage:
    python generate_schema.py
"""

import os
import subprocess
import sys

def main():
    print("🎵 Music Business Hub - Schema Generation")
    print("=" * 50)
    print()
    
    # Check if we're in a project directory
    if not os.path.exists("package.json"):
        print("❌ Error: package.json not found")
        print("Please run this script from your project root directory")
        sys.exit(1)
    
    # Check if drizzle config exists
    if not os.path.exists("drizzle.config.ts"):
        print("❌ Error: drizzle.config.ts not found")
        print("Please ensure you have Drizzle ORM configured")
        sys.exit(1)
    
    print("📋 Steps to generate schema:")
    print()
    print("1. Copy the schema template to your project:")
    print("   cp drizzle-schema-template.ts drizzle/schema.ts")
    print()
    print("2. Customize the schema for your needs:")
    print("   - Adjust table names")
    print("   - Add/remove fields")
    print("   - Modify enums")
    print()
    print("3. Generate migrations:")
    print("   pnpm drizzle-kit generate")
    print()
    print("4. Review the generated SQL file in drizzle/migrations/")
    print()
    print("5. Apply the migration:")
    print("   webdev_execute_sql < drizzle/migrations/[timestamp]_initial.sql")
    print()
    print("6. Verify the schema:")
    print("   pnpm drizzle-kit studio")
    print()
    
    # Offer to run drizzle-kit generate
    response = input("Would you like to run 'pnpm drizzle-kit generate' now? (y/n): ").strip().lower()
    
    if response == 'y':
        print()
        print("Running: pnpm drizzle-kit generate")
        print()
        try:
            result = subprocess.run(["pnpm", "drizzle-kit", "generate"], check=True)
            print()
            print("✅ Migration generated successfully!")
            print()
            print("Next steps:")
            print("1. Review the generated SQL in drizzle/migrations/")
            print("2. Apply it using webdev_execute_sql")
            print("3. Update server/db.ts with query helpers")
            print("4. Update server/routers.ts with tRPC procedures")
        except subprocess.CalledProcessError as e:
            print()
            print("❌ Error running drizzle-kit generate")
            print(f"Exit code: {e.returncode}")
            sys.exit(1)
    else:
        print()
        print("Skipped. Run 'pnpm drizzle-kit generate' when ready.")

if __name__ == "__main__":
    main()
