import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Loader2, Plus, Calendar } from "lucide-react";

const PILLARS = [
  { id: 'authority', label: 'סמכות', color: '#059cc0', description: 'תוכן טכני ומקצועי' },
  { id: 'energy', label: 'אנרגיה', color: '#03b28c', description: 'רגעים מרגשים מהרחבה' },
  { id: 'mentor', label: 'מנטור', color: '#1f1f21', description: 'טיפים וחינוך' },
  { id: 'person', label: 'אישיות', color: '#059cc0', description: 'דעות וערכים אישיים' },
];

const PLATFORMS = [
  { id: 'instagram_reel', label: 'Reel' },
  { id: 'instagram_story', label: 'Story' },
  { id: 'instagram_post', label: 'Post' },
  { id: 'instagram_carousel', label: 'Carousel' },
];

export default function ContentPlanner() {
  const { user } = useAuth();
  const { data: contentList, isLoading, refetch } = trpc.content.list.useQuery();
  const createMutation = trpc.content.create.useMutation({
    onSuccess: () => {
      refetch();
      setIsOpen(false);
      resetForm();
    },
  });

  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    pillar: 'authority',
    platform: 'instagram_reel',
    content: '',
    hooks: '',
    captions: '',
    hashtags: '',
    scheduledDate: '',
  });

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      pillar: 'authority',
      platform: 'instagram_reel',
      content: '',
      hooks: '',
      captions: '',
      hashtags: '',
      scheduledDate: '',
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await createMutation.mutateAsync({
      title: formData.title,
      description: formData.description,
      pillar: formData.pillar as 'authority' | 'energy' | 'mentor' | 'person',
      platform: formData.platform as 'instagram_reel' | 'instagram_story' | 'instagram_post' | 'instagram_carousel',
      content: formData.content,
      hooks: formData.hooks,
      captions: formData.captions,
      hashtags: formData.hashtags,
      scheduledDate: formData.scheduledDate ? new Date(formData.scheduledDate) : undefined,
    });
  };

  if (!user) return null;

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-foreground">תכנון תוכן</h1>
            <p className="text-muted-foreground mt-2">תכננו את התוכן החודשי שלכם עם 4 עמודים</p>
          </div>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                תוכן חדש
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>צרו תוכן חדש</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-sm font-medium">כותרת</label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="לדוגמה: טיפ מיקס חתונה"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">עמוד</label>
                    <Select value={formData.pillar} onValueChange={(value) => setFormData({ ...formData, pillar: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PILLARS.map((p) => (
                          <SelectItem key={p.id} value={p.id}>
                            {p.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium">פלטפורמה</label>
                    <Select value={formData.platform} onValueChange={(value) => setFormData({ ...formData, platform: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PLATFORMS.map((p) => (
                          <SelectItem key={p.id} value={p.id}>
                            {p.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium">תיאור</label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="תיאור קצר של התוכן"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">Hooks (קישוטים)</label>
                  <Textarea
                    value={formData.hooks}
                    onChange={(e) => setFormData({ ...formData, hooks: e.target.value })}
                    placeholder="כתבו קישוטים שיעזרו לתוכן להיות מעניין"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">כתוביות</label>
                  <Textarea
                    value={formData.captions}
                    onChange={(e) => setFormData({ ...formData, captions: e.target.value })}
                    placeholder="כתוביות עבור הפוסט"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">Hashtags</label>
                  <Input
                    value={formData.hashtags}
                    onChange={(e) => setFormData({ ...formData, hashtags: e.target.value })}
                    placeholder="#דיגיי #חתונה #מוזיקה"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">תאריך פרסום</label>
                  <Input
                    type="datetime-local"
                    value={formData.scheduledDate}
                    onChange={(e) => setFormData({ ...formData, scheduledDate: e.target.value })}
                  />
                </div>

                <Button type="submit" disabled={createMutation.isPending} className="w-full">
                  {createMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      שומר...
                    </>
                  ) : (
                    'שמור תוכן'
                  )}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Pillars Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {PILLARS.map((pillar) => (
            <Card key={pillar.id} className="border-t-4" style={{ borderTopColor: pillar.color }}>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">{pillar.label}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{pillar.description}</p>
                <p className="text-xs text-muted-foreground mt-3">
                  {contentList?.filter(c => c.pillar === pillar.id).length || 0} פוסטים
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Content Calendar */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              לוח שנה חודשי
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : contentList && contentList.length > 0 ? (
              <div className="space-y-3">
                {contentList.map((content) => {
                  const pillar = PILLARS.find(p => p.id === content.pillar);
                  return (
                    <div key={content.id} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <div
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: pillar?.color }}
                            />
                            <span className="font-medium">{content.title}</span>
                            <span className="text-xs px-2 py-1 rounded-full bg-muted">
                              {content.platform}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground">{content.description}</p>
                          {content.scheduledDate && (
                            <p className="text-xs text-muted-foreground mt-2">
                              📅 {new Date(content.scheduledDate).toLocaleDateString('he-IL')}
                            </p>
                          )}
                        </div>
                        <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800">
                          {content.status}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-8">אין תוכן עדיין. התחילו בלחיצה על "תוכן חדש"</p>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
